package com.example

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.ui.screens.MainAppScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.util.AmbientSynth

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    // Initialize ambient synth based on preferences
    val prefs = getSharedPreferences("patili_diyet_prefs", Context.MODE_PRIVATE)
    val musicEnabled = prefs.getBoolean("bg_music_enabled", true) // Enabled by default!
    AmbientSynth.initSynth(musicEnabled)

    // Schedule water reminders and daily discipline checks
    MealReminderScheduler.scheduleWaterReminder(applicationContext)
    MealReminderScheduler.scheduleDailyDisciplineCheck(applicationContext)

    setContent {
      MyApplicationTheme {
        MainAppScreen()
      }
    }
  }

  override fun onResume() {
    super.onResume()
    val prefs = getSharedPreferences("patili_diyet_prefs", Context.MODE_PRIVATE)
    val musicEnabled = prefs.getBoolean("bg_music_enabled", true)
    if (musicEnabled) {
      AmbientSynth.start()
    }
  }

  override fun onPause() {
    super.onPause()
    AmbientSynth.stop()
  }
}
