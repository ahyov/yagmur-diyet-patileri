package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "weight_records")
data class WeightRecord(
    @PrimaryKey val date: String, // Format: YYYY-MM-DD
    val weight: Float,
    val calorieIntake: Int,
    val calorieBurned: Int
)

@Entity(tableName = "body_measurements")
data class BodyMeasurement(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String, // Format: YYYY-MM-DD
    val waist: Float,
    val hips: Float,
    val chest: Float,
    val arm: Float,
    val leg: Float,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_profiles")
data class UserProfile(
    @PrimaryKey val id: Int = 1,
    val name: String = "Yağmur",
    val startWeight: Float = 65.0f,
    val targetWeight: Float = 55.0f,
    val xp: Int = 100
)
