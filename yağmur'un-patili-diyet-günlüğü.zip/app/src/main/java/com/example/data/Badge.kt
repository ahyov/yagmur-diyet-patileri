package com.example.data

data class Badge(
    val id: Int,
    val name: String,
    val description: String,
    val unlockCriteria: String,
    val isXpBased: Boolean,
    val threshold: Float, // XP threshold or Weight Loss threshold in kg
    val quote: String // Unique congratulatory phrase from the kitty
)
