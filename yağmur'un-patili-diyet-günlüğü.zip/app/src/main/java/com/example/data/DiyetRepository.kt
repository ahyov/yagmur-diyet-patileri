package com.example.data

import kotlinx.coroutines.flow.Flow

class DiyetRepository(private val database: AppDatabase) {
    val weightRecords: Flow<List<WeightRecord>> = database.weightRecordDao().getAllRecords()
    val bodyMeasurements: Flow<List<BodyMeasurement>> = database.bodyMeasurementDao().getAllMeasurements()
    val userProfile: Flow<UserProfile?> = database.userProfileDao().getProfile()

    suspend fun insertWeightRecord(record: WeightRecord) {
        database.weightRecordDao().insertRecord(record)
    }

    suspend fun deleteWeightRecord(record: WeightRecord) {
        database.weightRecordDao().deleteRecord(record)
    }

    suspend fun insertBodyMeasurement(measurement: BodyMeasurement) {
        database.bodyMeasurementDao().insertMeasurement(measurement)
    }

    suspend fun deleteBodyMeasurement(id: Long) {
        database.bodyMeasurementDao().deleteMeasurementById(id)
    }

    suspend fun updateProfile(profile: UserProfile) {
        database.userProfileDao().insertOrUpdateProfile(profile)
    }
}
