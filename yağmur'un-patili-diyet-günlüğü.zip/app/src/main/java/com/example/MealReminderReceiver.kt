package com.example

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import java.text.SimpleDateFormat
import java.util.*

class MealReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val isWater = intent.getBooleanExtra("is_water_reminder", false)
        val isDiscipline = intent.getBooleanExtra("is_discipline_check", false)

        if (isDiscipline) {
            val prefs = context.getSharedPreferences("patili_diyet_prefs", Context.MODE_PRIVATE)
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val lastCheatDate = prefs.getString("last_cheat_date", "") ?: ""
            val hasCheatedToday = lastCheatDate == todayStr

            if (!hasCheatedToday) {
                showDisciplineCelebrationNotification(
                    context,
                    "Harika Disiplin Günü! 🏆🐾",
                    "Yağmur bugün hiç kaçamak yapmadın! Kedilerin seninle kutlama yapmak için can atıyor, tıkla ve dansı gör! 💃🐈"
                )
            }
            return
        }

        val mealName = intent.getStringExtra("meal_name") ?: "Öğün"
        val message = if (isWater) {
            listOf(
                "Miyav! Yağmur, su içtin mi bakalım? Cildini ve patilerini taze tut! 💧🐾",
                "Pufpuf su içme seansını başlatıyor! Hemen kocaman bir bardak su iç, disiplin! 💧🐈",
                "Ben Milka! Canım süt çekti ama sana su içmeyi öneriyorum şapşal şey! 😹💧🤍",
                "Su içmek metabolizmanı hızlandırır mırrr! Haydi bir yudum su al! 💧✨"
            ).random()
        } else {
            intent.getStringExtra("meal_message") ?: "Beslenme saatimiz geldi, hadi tabağımızı patileyelim! 🐾"
        }
        
        showNotification(context, mealName, message)
    }

    private fun showDisciplineCelebrationNotification(context: Context, title: String, text: String) {
        val channelId = "patili_diyet_discipline_notifications"
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelName = "Disiplin Kutlama Bildirimleri"
            val channelDescription = "Günlük kaçamaksız diyet kutlama bildirimleri"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(channelId, channelName, importance).apply {
                description = channelDescription
            }
            notificationManager.createNotificationChannel(channel)
        }

        val clickIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("show_dance_celebration", true)
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            777,
            clickIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_paw_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setColor(0xFFFF94B9.toInt())
            .build()

        try {
            notificationManager.notify(777, notification)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showNotification(context: Context, title: String, text: String) {
        val channelId = "patili_diyet_notifications"
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelName = "Patili Diyet Hatırlatıcıları"
            val channelDescription = "Günlük beslenme ve öğün hatırlatıcı bildirimleri"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(channelId, channelName, importance).apply {
                description = channelDescription
            }
            notificationManager.createNotificationChannel(channel)
        }

        // Click action to open MainActivity
        val clickIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            clickIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Built-in cute message notification decoration
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_paw_notification)
            .setContentTitle("Miyav! $title Zamanı! 🐾")
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setColor(0xFFFF94B9.toInt()) // CutePinkPrimary
            .build()

        notificationManager.notify(title.hashCode(), notification)
    }
}
