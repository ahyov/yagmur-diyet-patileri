package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = DarkPinkPrimary,
    secondary = DarkPinkSecondary,
    tertiary = CutePinkTertiary,
    background = DarkCreamBackground,
    surface = DarkCreamSurface,
    onPrimary = DarkTextDark,
    onSecondary = DarkTextDark,
    onBackground = DarkTextDark,
    onSurface = DarkTextDark,
    onSurfaceVariant = DarkTextLight
)

private val LightColorScheme = lightColorScheme(
    primary = CutePinkPrimary,
    secondary = CutePinkSecondary,
    tertiary = CutePinkTertiary,
    background = CuteCreamBackground,
    surface = CuteCreamSurface,
    onPrimary = CuteCreamBackground,
    onSecondary = TextDark,
    onBackground = TextDark,
    onSurface = TextDark,
    onSurfaceVariant = TextLight
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Set to false to preserve the customized soft-pink cute cat brand colors!
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
