package com.example.ui.screens

import android.widget.Toast
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.BodyMeasurement
import com.example.data.WeightRecord
import com.example.data.Badge
import android.app.Activity
import com.example.ui.DiyetViewModel
import com.example.ui.components.CuteCatFace
import com.example.ui.components.CuteCatPaw
import com.example.ui.components.CuteConfetti
import com.example.ui.components.PixelArtPufpuf
import com.example.ui.components.PixelArtMilka
import androidx.compose.ui.zIndex

import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(
    viewModel: DiyetViewModel = viewModel()
) {
    var selectedTab by remember { mutableStateOf(0) }
    val showConfetti by viewModel.showConfetti.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()

    var showProfileDialog by remember { mutableStateOf(false) }
    var showQuickRecordDialog by remember { mutableStateOf(false) }
    var showUpdateNotesDialog by remember { mutableStateOf(false) }
    var showDanceCelebration by remember { mutableStateOf(false) }

    val contextForSound = LocalContext.current

    LaunchedEffect(Unit) {
        val prefs = contextForSound.getSharedPreferences("patili_diyet_prefs", android.content.Context.MODE_PRIVATE)
        val alreadyShown = prefs.getBoolean("update_v2_notes_shown", false)
        if (!alreadyShown) {
            showUpdateNotesDialog = true
        }

        val activity = contextForSound as? Activity
        val showDance = activity?.intent?.getBooleanExtra("show_dance_celebration", false) ?: false
        if (showDance) {
            showDanceCelebration = true
            activity?.intent?.removeExtra("show_dance_celebration")
        }
    }

    // State for periodic cat popups (30 seconds cycle)
    var activeCatByTimer by remember { mutableStateOf<String?>(null) } // "Pufpuf", "Milka", or null
    var activeCatPhrase by remember { mutableStateOf("") }
    var activeCatLeftCorner by remember { mutableStateOf(true) }

    // List of serious coaching quotes for Pufpuf (Gri tekir kedi)
    val pufpufPhrases = remember {
        listOf(
            "Duruşun harika ama o çikolatayı yavaşça yere bırak Yağmur! Ciddiyet! 🐾🩶",
            "Miyav! Bugünü kaç kaloriyle kapatacaksın bakalım? Takipteyim! 📈🐈",
            "Egzersizini yaptın mı? Disiplin her şeydir, mırrr! 🐾🏋️‍♂️",
            "Yağmur! Hedefe ulaşana kadar kaçamak yok, patilerimiz daima çalışmalı! 🐾🔥",
            "Ölçülerini kaydetmeyi unutma. Gelişimi takip etmeyen kedi, mamasını hak etmez! 🐾📏",
            "Ben Pufpuf. Bugün senin disiplin koçun benim. Su içtin mi bakalım? 💧🐈",
            "Bir kase dondurma mı? Yağmur, hayır! Onun yerine bir elma ısır, disiplin mırrr! 🍏😾",
            "Gözlerim üzerinde tatlış. Aldığın her protein patilerimize can katıyor! 💪🐾",
            "Hım... Bugün kaç adım attık? Pufpuf rapor bekliyor, miyav! 👣🩶",
            "Tartı yalan söylemez Yağmur! Hedefimiz için bugünü yeşil kapatıyoruz! 🥗🐾"
        )
    }

    // List of silly, funny quotes for Milka (Bembeyaz uzun tüylü Ankara kedisi)
    val milkaPhrases = remember {
        listOf(
            "Miyavvv! Canım fıstık ezmeli lahmacun çekti şapşal şey! 😹🌭",
            "Kilo vermek de neymiş, bir kase kedi maması her şeye bedel! Şaka şaka, harikasın tatlış! 🐟🌸",
            "Mırrr... Uyku saati gelmedi mi ya? Çok yorulduk ama değecek şapşalım! 😴🐾",
            "Ben Milka, bugünü mırıldayarak şapşal şapşal geçirelim! 🐱💖",
            "Günde 5000 adım mı? Ben koltuktan televizyona gidemiyorum, sen muhteşemsin Yağmur! 😹✨",
            "Diyet mi? Ben sadece mama kabını boşaltma diyeti yapıyorum şapşal şey! 😹🐾",
            "Eğer canın tatlı çekerse beni gıdıla şapşalım, sıfır kalori mırrr! 🐱🍬",
            "Ben diyet yapmayı denedim, 3 saniye sürdü... Sen nasıl dayanıyorsun hahah! 😹🌸",
            "Yağmur! Pufpuf görmeden şuraya bir dilim pizza saklasak mı, ne dersin? 🍕😹🤐",
            "Tombul olmak da bir sanattır şapşal şey, ama senin fitliğin de ayrı bir asil duruyor! 🤍🐾"
        )
    }

    LaunchedEffect(Unit) {
        var lastWasPufpuf = false
        while (true) {
            // Wait for 15 seconds (cat is hidden)
            kotlinx.coroutines.delay(15000L)
            
            // Choose the alternating cat
            val isPufpuf = !lastWasPufpuf
            lastWasPufpuf = isPufpuf
            
            activeCatLeftCorner = kotlin.random.Random.nextBoolean()
            activeCatByTimer = if (isPufpuf) "Pufpuf" else "Milka"
            activeCatPhrase = if (isPufpuf) pufpufPhrases.random() else milkaPhrases.random()
            
            // Play corresponding sound! (Purr for Pufpuf, Meow for Milka)
            if (isPufpuf) {
                com.example.util.AmbientSynth.playPurr(contextForSound)
            } else {
                com.example.util.AmbientSynth.playMeow(contextForSound)
            }

            // Stay on screen for 15 seconds
            kotlinx.coroutines.delay(15000L)
            
            // Hide
            activeCatByTimer = null
        }
    }


    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        CuteCatPaw(modifier = Modifier.size(28.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Patili Diyet Günlüğü",
                            fontWeight = FontWeight.Bold,
                            color = TextDark,
                            fontSize = 20.sp
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showProfileDialog = true },
                        modifier = Modifier.testTag("settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Ayarlar",
                            tint = TextDark
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = CutePinkTertiary.copy(alpha = 0.5f)
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = CutePinkTertiary.copy(alpha = 0.4f),
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Pets, contentDescription = "Ana Sayfa") },
                    label = { Text("Ana Sayfa", fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CutePinkPrimary,
                        selectedTextColor = TextDark,
                        indicatorColor = CutePinkTertiary,
                        unselectedIconColor = TextLight,
                        unselectedTextColor = TextLight
                    ),
                    modifier = Modifier.testTag("tab_home")
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Straighten, contentDescription = "Ölçü Takibi") },
                    label = { Text("Ölçüler", fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CutePinkPrimary,
                        selectedTextColor = TextDark,
                        indicatorColor = CutePinkTertiary,
                        unselectedIconColor = TextLight,
                        unselectedTextColor = TextLight
                    ),
                    modifier = Modifier.testTag("tab_measures")
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.NoteAlt, contentDescription = "Post-it Duvarı") },
                    label = { Text("Post-it Duvarı", fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CutePinkPrimary,
                        selectedTextColor = TextDark,
                        indicatorColor = CutePinkTertiary,
                        unselectedIconColor = TextLight,
                        unselectedTextColor = TextLight
                    ),
                    modifier = Modifier.testTag("tab_calendar")
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.EmojiEvents, contentDescription = "Başarılarım") },
                    label = { Text("Başarılar", fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CutePinkPrimary,
                        selectedTextColor = TextDark,
                        indicatorColor = CutePinkTertiary,
                        unselectedIconColor = TextLight,
                        unselectedTextColor = TextLight
                    ),
                    modifier = Modifier.testTag("tab_achievements")
                )
            }
        },
        floatingActionButton = {
            if (selectedTab == 0 || selectedTab == 2) {
                ExtendedFloatingActionButton(
                    onClick = { showQuickRecordDialog = true },
                    containerColor = CutePinkPrimary,
                    contentColor = Color.White,
                    elevation = FloatingActionButtonDefaults.elevation(6.dp),
                    modifier = Modifier.testTag("fab_add_record")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Kayıt Ekle")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Bugünü Kaydet 🐾", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> HomeScreen(viewModel = viewModel, onEditProfile = { showProfileDialog = true })
                1 -> MeasurementsScreen(viewModel = viewModel)
                2 -> PostitCalendarScreen(viewModel = viewModel)
                3 -> AchievementsScreen(viewModel = viewModel)
            }

            // Full Screen 10kg Lost Celebration Screen
            FullScreen10KgCelebration(viewModel = viewModel)

            // Confetti Overlay
            if (showConfetti) {
                Box(modifier = Modifier.fillMaxSize()) {
                    CuteConfetti(modifier = Modifier.fillMaxSize())
                    
                    // Cute congratulatory banner
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                            .align(Alignment.Center)
                            .shadow(8.dp, RoundedCornerShape(24.dp))
                            .background(Color.White, RoundedCornerShape(24.dp))
                            .border(3.dp, CutePinkPrimary, RoundedCornerShape(24.dp))
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CuteCatFace(modifier = Modifier.size(100.dp))
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "MİYAVV! 🎉",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = CutePinkPrimary,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Harika gidiyorsun Yağmur! Kilo verdin ve ek pati rozetleri kazandın! 😻🐾",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextDark,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { viewModel.dismissConfetti() },
                                colors = ButtonDefaults.buttonColors(containerColor = CutePinkPrimary)
                            ) {
                                Text("Çok Teşekkürler! 💖", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Dialogs
            if (showProfileDialog) {
                ProfileSettingsDialog(
                    userProfile = userProfile,
                    onDismiss = { showProfileDialog = false },
                    onSave = { name, start, target ->
                        viewModel.updateProfileSettings(name, start, target)
                        showProfileDialog = false
                    }
                )
            }

            val weightRecords by viewModel.weightRecords.collectAsStateWithLifecycle()
            val lastRegisteredWeight = remember(weightRecords) {
                weightRecords.sortedBy { it.date }.lastOrNull()?.weight ?: 0.0f
            }

            if (showQuickRecordDialog) {
                val realTodayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                QuickRecordDialog(
                    dateStr = realTodayStr,
                    initialWeight = lastRegisteredWeight,
                    onDismiss = { showQuickRecordDialog = false },
                    onSave = { weight, intake, burned ->
                        viewModel.addWeightRecord(realTodayStr, weight, intake, burned)
                        showQuickRecordDialog = false
                    }
                )
            }

            if (showUpdateNotesDialog) {
                UpdateNotesDialog(
                    onDismiss = {
                        val prefs = contextForSound.getSharedPreferences("patili_diyet_prefs", android.content.Context.MODE_PRIVATE)
                        prefs.edit().putBoolean("update_v2_notes_shown", true).apply()
                        showUpdateNotesDialog = false
                    }
                )
            }

            if (showDanceCelebration) {
                DancingCatsCelebrationDialog(
                    onDismiss = { showDanceCelebration = false }
                )
            }

            val newlyUnlockedBadge by viewModel.newlyUnlockedBadge.collectAsStateWithLifecycle()
            if (newlyUnlockedBadge != null) {
                BadgeUnlockCelebrationDialog(
                    badge = newlyUnlockedBadge!!,
                    onDismiss = { viewModel.clearNewlyUnlockedBadge() }
                )
            }

            // --- FLOATING NON-BLOCKING PERIODIC PIXEL-ART CAT POPUP ---
            if (activeCatByTimer != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .zIndex(99f) // Display above standard screens but beneath modal dialogs if needed
                ) {
                    Card(
                        modifier = Modifier
                            .align(if (activeCatLeftCorner) Alignment.BottomStart else Alignment.BottomEnd)
                            .padding(horizontal = 16.dp, vertical = 76.dp) // Lifted above the bottom navigation bar safely
                            .widthIn(max = 260.dp)
                            .shadow(12.dp, RoundedCornerShape(20.dp)),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(2.dp, CutePinkPrimary.copy(alpha = 0.8f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (activeCatLeftCorner) {
                                // Left: Pixel Art Cat Canvas
                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .background(CutePinkTertiary.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                                        .padding(4.dp)
                                ) {
                                    if (activeCatByTimer == "Pufpuf") {
                                        PixelArtPufpuf(modifier = Modifier.fillMaxSize())
                                    } else {
                                        PixelArtMilka(modifier = Modifier.fillMaxSize())
                                    }
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                // Right: Chat bubble
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = if (activeCatByTimer == "Pufpuf") "Pufpuf 🩶" else "Milka 🤍",
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 13.sp,
                                            color = if (activeCatByTimer == "Pufpuf") Color(0xFF515151) else CutePinkPrimary
                                        )
                                        IconButton(
                                            onClick = { activeCatByTimer = null },
                                            modifier = Modifier.size(20.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Close,
                                                contentDescription = "Kapat",
                                                tint = Color.Gray,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = activeCatPhrase,
                                        fontSize = 11.sp,
                                        color = TextDark,
                                        lineHeight = 14.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            } else {
                                // Right-aligned layout (Bubble left, Cat right)
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = if (activeCatByTimer == "Pufpuf") "Pufpuf 🩶" else "Milka 🤍",
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 13.sp,
                                            color = if (activeCatByTimer == "Pufpuf") Color(0xFF515151) else CutePinkPrimary
                                        )
                                        IconButton(
                                            onClick = { activeCatByTimer = null },
                                            modifier = Modifier.size(20.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Close,
                                                contentDescription = "Kapat",
                                                tint = Color.Gray,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = activeCatPhrase,
                                        fontSize = 11.sp,
                                        color = TextDark,
                                        lineHeight = 14.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .background(CutePinkTertiary.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                                        .padding(4.dp)
                                ) {
                                    if (activeCatByTimer == "Pufpuf") {
                                        PixelArtPufpuf(modifier = Modifier.fillMaxSize())
                                    } else {
                                        PixelArtMilka(modifier = Modifier.fillMaxSize())
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
fun HomeScreen(
    viewModel: DiyetViewModel,
    onEditProfile: () -> Unit
) {
    val profile by viewModel.userProfile.collectAsStateWithLifecycle()
    val records by viewModel.weightRecords.collectAsStateWithLifecycle()
    val latestPhrase by viewModel.currentCatPhrase.collectAsStateWithLifecycle()

    val sortedRecords = remember(records) { records.sortedByDescending { it.date } }
    val latestRecord = sortedRecords.firstOrNull()

    val currentWeight = latestRecord?.weight ?: profile.startWeight
    val targetWeight = profile.targetWeight
    val startWeight = profile.startWeight

    // Calculate level based on XP
    val level = (profile.xp / 100) + 1
    val currentLevelXp = profile.xp % 100

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(CutePinkTertiary.copy(alpha = 0.15f), CuteCreamBackground)
                )
            )
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Header with Cute Cat Face
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(4.dp, RoundedCornerShape(24.dp)),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(24.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CuteCatFace(modifier = Modifier.size(80.dp))
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = "Hoş geldin ${profile.name}! 🐾",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextDark
                        )
                        Text(
                            text = "Bugün patili bir başlangıç yap! ✨",
                            fontSize = 14.sp,
                            color = TextLight
                        )
                    }
                }
            }
        }

        // Success Points (XP) & Levels Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(4.dp, RoundedCornerShape(24.dp)),
                colors = CardDefaults.cardColors(containerColor = CuteCreamSurface),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.5.dp, CutePinkPrimary.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.WorkspacePremium,
                                contentDescription = "Rozet",
                                tint = CutePinkPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Başarı Seviyen",
                                fontWeight = FontWeight.Bold,
                                color = TextDark,
                                fontSize = 16.sp
                            )
                        }
                        Badge(
                            containerColor = CutePinkPrimary,
                            contentColor = Color.White,
                            modifier = Modifier.padding(4.dp)
                        ) {
                            Text("Seviye $level", fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Başarı Puanı: ${profile.xp} XP",
                            fontWeight = FontWeight.Bold,
                            color = TextDark,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "Seviye Atlama: $currentLevelXp / 100 XP",
                            fontSize = 12.sp,
                            color = TextLight
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Custom styled progress bar for XP
                    LinearProgressIndicator(
                        progress = { currentLevelXp.toFloat() / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(CircleShape),
                        color = CutePinkPrimary,
                        trackColor = Color.White
                    )
                }
            }
        }

        // Cute Motivation Cat Speech Bubble
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(3.dp, RoundedCornerShape(20.dp))
                        .background(Color(0xFFFFF0F3), RoundedCornerShape(20.dp))
                        .border(1.5.dp, CutePinkSecondary, RoundedCornerShape(20.dp))
                        .padding(16.dp)
                ) {
                    Text(
                        text = latestPhrase,
                        fontWeight = FontWeight.Bold,
                        color = TextDark,
                        fontSize = 15.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                // Little pointer pointing down towards the cat icon or visual decoration
                Box(
                    modifier = Modifier
                        .padding(start = 48.dp)
                        .size(16.dp)
                        .rotate(45f)
                        .background(Color(0xFFFFF0F3))
                        .border(
                            width = 1.5.dp,
                            brush = Brush.linearGradient(listOf(CutePinkSecondary, CutePinkSecondary)),
                            shape = RoundedCornerShape(0.dp)
                        )
                        // Crop out the top-left to make it appear as a neat speech bubble pointer
                )
            }
        }

        // Fish Bone Cheat Counter Card
        item {
            val cheatCount by viewModel.cheatCount.collectAsStateWithLifecycle()
            val showAnimation by viewModel.showCheatAnimation.collectAsStateWithLifecycle()

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(4.dp, RoundedCornerShape(24.dp)),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "🦴 Balık Kılçığı Kaçamak Sayacı",
                                fontWeight = FontWeight.Bold,
                                color = TextDark,
                                fontSize = 16.sp
                            )
                        }
                        
                        Badge(
                            containerColor = Color(0xFFFF9800),
                            contentColor = Color.White
                        ) {
                            Text(
                                text = "$cheatCount Kaçamak",
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (showAnimation) {
                        FishStealingAnimation(
                            visible = showAnimation,
                            onAnimationEnd = { viewModel.dismissCheatAnimation() }
                        )
                    } else {
                        Button(
                            onClick = { viewModel.incrementCheatCount() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFF3E0)),
                            border = BorderStroke(1.5.dp, Color(0xFFFFB74D)),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth().testTag("cheat_bone_button")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier.padding(vertical = 4.dp)
                            ) {
                                Text(
                                    text = "🐟 Kaçamak Yaptım (Balık Ekle) 🐾",
                                    color = Color(0xFFE65100),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Diyet dışı bir kaçamak yaptığında bu butona basarak dürüstçe kaydet. Milka balığı çalarken Pufpuf disiplini korumanı fısıldasın! 😉🐾",
                        fontSize = 11.sp,
                        color = TextLight,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
                    )
                }
            }
        }

        // Weight Progress Bar / Goals Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(4.dp, RoundedCornerShape(24.dp)),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Kilo İlerleme Çubuğu 🐾",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = TextDark
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    // Weight details row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Başlangıç", fontSize = 12.sp, color = TextLight)
                            Text("$startWeight kg", fontWeight = FontWeight.Bold, color = TextDark, fontSize = 15.sp)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Güncel", fontSize = 12.sp, color = CutePinkPrimary, fontWeight = FontWeight.Bold)
                            Text("$currentWeight kg", fontWeight = FontWeight.ExtraBold, color = CutePinkPrimary, fontSize = 18.sp)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Hedef", fontSize = 12.sp, color = TextLight)
                            Text("$targetWeight kg", fontWeight = FontWeight.Bold, color = TextDark, fontSize = 15.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Advanced graphic progress bar with a cute sliding paw!
                    val totalDiff = startWeight - targetWeight
                    val currentProgress = if (totalDiff > 0f) {
                        val currentDiff = startWeight - currentWeight
                        (currentDiff / totalDiff).coerceIn(0f, 1f)
                    } else {
                        1f
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(28.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        // Progress track background
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(12.dp)
                                .clip(CircleShape)
                                .background(CuteCreamSurface)
                                .border(1.dp, CutePinkSecondary.copy(alpha = 0.5f), CircleShape)
                        )
                        // Active track
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(currentProgress)
                                .height(12.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(CutePinkSecondary, CutePinkPrimary)
                                    )
                                )
                        )
                        // Sliding cat paw icon as current progress slider
                        Box(
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .padding(
                                    start = if (currentProgress > 0.05f) {
                                        (currentProgress * 280).dp // Estimate dynamic offset
                                    } else 0.dp
                                )
                        ) {
                            CuteCatPaw(modifier = Modifier.size(24.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    val remainingWeight = currentWeight - targetWeight
                    if (remainingWeight > 0f) {
                        Text(
                            text = "Hedefine sadece ${String.format("%.1f", remainingWeight)} kg kaldı! 🐾 Hırslı kedi hedefe doğru patiler!",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextLight,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        Text(
                            text = "Tebrikler Yağmur! Hedef kilona ulaştın ve harika bir patilisin! 😻👑",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF4CAF50),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }

        // Meal Reminders Section
        item {
            Spacer(modifier = Modifier.height(16.dp))
            MealReminderSection(viewModel = viewModel)
        }

        // Recent Logs Title
        item {
            Text(
                text = "Son Günlük Kayıtları 📖",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = TextDark,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        // Recent Weight Logs List
        if (sortedRecords.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notes,
                            contentDescription = "Boş",
                            tint = TextLight,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Henüz kilo kaydı girmemişsin, Yağmur.",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextDark
                        )
                        Text(
                            text = "Kayıt eklemek için 'Bugünü Kaydet' butonunu kullanabilirsin. 🐾",
                            fontSize = 12.sp,
                            color = TextLight,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        } else {
            items(sortedRecords.take(5)) { record ->
                WeightRecordRow(record = record, onDelete = { viewModel.deleteWeightRecord(record) })
            }
        }
    }
}

@Composable
fun WeightRecordRow(
    record: WeightRecord,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(2.dp, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Circle paw badge
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(CutePinkTertiary.copy(alpha = 0.4f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    CuteCatPaw(modifier = Modifier.size(24.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    // Format date elegantly (e.g., 3 Temmuz Cuma)
                    val formattedDate = try {
                        val inputFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                        val date = inputFormat.parse(record.date)
                        val outputFormat = SimpleDateFormat("d MMMM EEEE", Locale("tr"))
                        outputFormat.format(date!!)
                    } catch (e: Exception) {
                        record.date
                    }

                    Text(
                        text = formattedDate,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = TextDark
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "🥗 +${record.calorieIntake} kcal",
                            fontSize = 12.sp,
                            color = Color(0xFFE65100),
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "🏃 -${record.calorieBurned} kcal",
                            fontSize = 12.sp,
                            color = Color(0xFF2E7D32),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "${record.weight} kg",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp,
                    color = CutePinkPrimary
                )
                Spacer(modifier = Modifier.width(4.dp))
                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Sil",
                        tint = Color.Red.copy(alpha = 0.6f)
                    )
                }
            }
        }
    }
}

@Composable
fun MeasurementsScreen(
    viewModel: DiyetViewModel
) {
    val measurements by viewModel.bodyMeasurements.collectAsStateWithLifecycle()

    var waist by remember { mutableStateOf("") }
    var hips by remember { mutableStateOf("") }
    var chest by remember { mutableStateOf("") }
    var arm by remember { mutableStateOf("") }
    var leg by remember { mutableStateOf("") }

    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CuteCreamBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Measurement Input Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(4.dp, RoundedCornerShape(24.dp)),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.5.dp, CutePinkTertiary)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Straighten,
                            contentDescription = "Ruler",
                            tint = CutePinkPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Ölçü Giriş Paneli (cm) 📏",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = TextDark
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Measurements Inputs Grid / Fields
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        MeasurementInputField(label = "Bel Ölçüsü", value = waist, onValueChange = { waist = it })
                        MeasurementInputField(label = "Basen Ölçüsü", value = hips, onValueChange = { hips = it })
                        MeasurementInputField(label = "Göğüs Ölçüsü", value = chest, onValueChange = { chest = it })
                        MeasurementInputField(label = "Kol Ölçüsü", value = arm, onValueChange = { arm = it })
                        MeasurementInputField(label = "Bacak Ölçüsü", value = leg, onValueChange = { leg = it })
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = {
                            val wVal = waist.toFloatOrNull() ?: 0f
                            val hVal = hips.toFloatOrNull() ?: 0f
                            val cVal = chest.toFloatOrNull() ?: 0f
                            val aVal = arm.toFloatOrNull() ?: 0f
                            val lVal = leg.toFloatOrNull() ?: 0f

                            if (wVal > 0f || hVal > 0f || cVal > 0f || aVal > 0f || lVal > 0f) {
                                val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                                viewModel.addBodyMeasurement(todayStr, wVal, hVal, cVal, aVal, lVal)
                                // Clear inputs
                                waist = ""
                                hips = ""
                                chest = ""
                                arm = ""
                                leg = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CutePinkPrimary),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("save_measurements_button")
                    ) {
                        Text("Ölçüleri Kaydet (+15 XP) 🐾", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
                    }
                }
            }
        }

        // Past Measurements Title
        item {
            Text(
                text = "Geçmiş Ölçü Takibi 📈",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = TextDark,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        // Past Measurements Records
        if (measurements.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "Boş Geçmiş",
                            tint = TextLight,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Kayıtlı ölçü bulunamadı.",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextDark
                        )
                        Text(
                            text = "Yukarıdaki panele cm ölçülerini yazarak ilk kaydı oluşturabilirsin! 🐾",
                            fontSize = 12.sp,
                            color = TextLight,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(measurements) { item ->
                MeasurementCard(measurement = item, onDelete = { viewModel.deleteBodyMeasurement(item.id) })
            }
        }
    }
}

@Composable
fun MeasurementInputField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, color = TextLight) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = CutePinkPrimary,
            unfocusedBorderColor = CutePinkSecondary.copy(alpha = 0.6f),
            focusedContainerColor = Color.White,
            unfocusedContainerColor = Color.White
        ),
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        trailingIcon = { Text("cm", fontWeight = FontWeight.Bold, color = TextLight, modifier = Modifier.padding(end = 8.dp)) }
    )
}

@Composable
fun MeasurementCard(
    measurement: BodyMeasurement,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(2.dp, RoundedCornerShape(20.dp)),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val formattedDate = try {
                    val inputFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                    val date = inputFormat.parse(measurement.date)
                    val outputFormat = SimpleDateFormat("d MMMM yyyy", Locale("tr"))
                    outputFormat.format(date!!)
                } catch (e: Exception) {
                    measurement.date
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = "Tarih",
                        tint = CutePinkPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = formattedDate,
                        fontWeight = FontWeight.Bold,
                        color = TextDark,
                        fontSize = 14.sp
                    )
                }

                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Sil",
                        tint = Color.Red.copy(alpha = 0.6f),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Body measurements horizontal flow / grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                MeasurementBadge(label = "Bel", value = measurement.waist)
                MeasurementBadge(label = "Basen", value = measurement.hips)
                MeasurementBadge(label = "Göğüs", value = measurement.chest)
                MeasurementBadge(label = "Kol", value = measurement.arm)
                MeasurementBadge(label = "Bacak", value = measurement.leg)
            }
        }
    }
}

@Composable
fun MeasurementBadge(
    label: String,
    value: Float
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .background(CutePinkTertiary.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(text = label, fontSize = 11.sp, color = TextLight, fontWeight = FontWeight.Bold)
        Text(
            text = if (value > 0) "${String.format("%.1f", value)} cm" else "-",
            fontSize = 13.sp,
            fontWeight = FontWeight.ExtraBold,
            color = TextDark
        )
    }
}

@Composable
fun PostitCalendarScreen(
    viewModel: DiyetViewModel
) {
    val records by viewModel.weightRecords.collectAsStateWithLifecycle()
    val selectedYear by viewModel.selectedYear.collectAsStateWithLifecycle()
    val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()

    var showDialogByDate by remember { mutableStateOf<String?>(null) }
    var existingRecordForDialog by remember { mutableStateOf<WeightRecord?>(null) }

    val calendar = Calendar.getInstance()
    calendar.set(Calendar.YEAR, selectedYear)
    calendar.set(Calendar.MONTH, selectedMonth - 1)
    calendar.set(Calendar.DAY_OF_MONTH, 1)

    val maxDay = calendar.getActualMaximum(Calendar.DAY_OF_MONTH)
    val firstDayOfWeek = calendar.get(Calendar.DAY_OF_WEEK) // 1 = Sunday, 2 = Monday, ...

    // Convert firstDayOfWeek to localized index where 0 = Monday, ..., 6 = Sunday
    val startOffset = if (firstDayOfWeek == Calendar.SUNDAY) 6 else firstDayOfWeek - 2

    val trMonths = listOf(
        "Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran",
        "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"
    )

    val monthName = trMonths[selectedMonth - 1]

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFFEFE5DB), Color(0xFFDCCFBE))
                )
            )
            .verticalScroll(rememberScrollState()) // Makes entire calendar page vertically scrollable for small screens!
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Month / Year Navigation Board
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
                .background(Color(0x334E3629), RoundedCornerShape(16.dp))
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.decrementMonth() }) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Önceki Ay",
                    tint = TextDark
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "$monthName $selectedYear 🐾",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextDark,
                    fontFamily = FontFamily.Cursive
                )
                Text(
                    text = "Post-it Duvar Takvimi",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextLight
                )
            }

            IconButton(onClick = { viewModel.incrementMonth() }) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "Sonraki Ay",
                    tint = TextDark
                )
            }
        }

        // Days of week row
        val trDays = listOf("Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz")
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            trDays.forEach { dayName ->
                Text(
                    text = dayName,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextDark,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center
                )
            }
        }

        // Post-it Calendar Grid utilizing robust Row + Column model to support seamless nested scrolling
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val totalCells = maxDay + startOffset
            val daysList = (0 until totalCells).toList()
            val rows = daysList.chunked(7)

            rows.forEach { rowIndices ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    rowIndices.forEach { index ->
                        val cellModifier = Modifier.weight(1f)
                        if (index < startOffset) {
                            // Padding cell placeholder
                            Box(modifier = cellModifier.aspectRatio(0.85f))
                        } else {
                            val day = index - startOffset + 1
                            val dateStr = String.format("%04d-%02d-%02d", selectedYear, selectedMonth, day)
                            val dayRecord = records.find { it.date == dateStr }

                            // Alternate Post-it colors beautifully!
                            val postitColors = listOf(PostitYellow, PostitPink, PostitBlue, PostitGreen, PostitOrange)
                            val postitColor = postitColors[day % postitColors.size]

                            PostitStickyNote(
                                dayNumber = day,
                                record = dayRecord,
                                backgroundColor = postitColor,
                                onClick = {
                                    existingRecordForDialog = dayRecord
                                    showDialogByDate = dateStr
                                },
                                modifier = cellModifier.testTag("postit_day_$day")
                            )
                        }
                    }
                    // Pad last row if incomplete
                    if (rowIndices.size < 7) {
                        repeat(7 - rowIndices.size) {
                            Box(modifier = Modifier.weight(1f).aspectRatio(0.85f))
                        }
                    }
                }
            }
        }
    }

    // Modal quick insert/edit dialog for clicked Post-it day
    if (showDialogByDate != null) {
        val dateStr = showDialogByDate!!
        CalendarQuickRecordDialog(
            dateStr = dateStr,
            existingRecord = existingRecordForDialog,
            onDismiss = {
                showDialogByDate = null
                existingRecordForDialog = null
            },
            onSave = { weight, intake, burned ->
                viewModel.addWeightRecord(dateStr, weight, intake, burned)
                showDialogByDate = null
                existingRecordForDialog = null
            }
        )
    }
}

@Composable
fun PostitStickyNote(
    dayNumber: Int,
    record: WeightRecord?,
    backgroundColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .aspectRatio(0.85f)
            .shadow(
                elevation = 4.dp,
                shape = RoundedCornerShape(2.dp),
                clip = false
            )
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        shape = RoundedCornerShape(2.dp),
        border = BorderStroke(1.dp, Color.Black.copy(alpha = 0.08f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Day number with handwritten feel
            Text(
                text = dayNumber.toString(),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 11.sp, // Slightly more compact to prevent overlapping on tiny viewports
                color = Color.Black.copy(alpha = 0.7f),
                fontFamily = FontFamily.Cursive,
                modifier = Modifier.align(Alignment.Start).padding(start = 2.dp)
            )

            if (record != null) {
                // Post-it details with handwritten font style and strict ellipsis constraints to protect layout integrity
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Kilo: ${record.weight} kg",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E1E1E),
                        fontFamily = FontFamily.Cursive,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "Alınan: ${record.calorieIntake} kcal",
                        fontSize = 7.5.sp,
                        color = Color(0xFFB71C1C),
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Cursive,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "Verilen: ${record.calorieBurned} kcal",
                        fontSize = 7.5.sp,
                        color = Color(0xFF1B5E20),
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Cursive,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            } else {
                // Empty state indicator
                Text(
                    text = "+ Ekle",
                    fontSize = 9.sp,
                    color = Color.Black.copy(alpha = 0.35f),
                    fontFamily = FontFamily.Cursive,
                    modifier = Modifier.padding(bottom = 4.dp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Minimal tape look at the bottom
            Spacer(modifier = Modifier.height(1.dp))
        }
    }
}


@Composable
fun ProfileSettingsDialog(
    userProfile: com.example.data.UserProfile,
    onDismiss: () -> Unit,
    onSave: (String, Float, Float) -> Unit
) {
    var name by remember { mutableStateOf(userProfile.name) }
    var startWeight by remember { mutableStateOf(userProfile.startWeight.toString()) }
    var targetWeight by remember { mutableStateOf(userProfile.targetWeight.toString()) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .shadow(8.dp, RoundedCornerShape(24.dp)),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CuteCatFace(modifier = Modifier.size(64.dp))
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Profil Ayarları 🐾",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = TextDark
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Kullanıcı Adı") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = CutePinkPrimary),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = startWeight,
                    onValueChange = { startWeight = it },
                    label = { Text("Başlangıç Kilosu (kg)") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = CutePinkPrimary),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = targetWeight,
                    onValueChange = { targetWeight = it },
                    label = { Text("Hedef Kilosu (kg)") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = CutePinkPrimary),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("İptal", color = TextDark)
                    }
                    Button(
                        onClick = {
                            val startVal = startWeight.toFloatOrNull() ?: 65f
                            val targetVal = targetWeight.toFloatOrNull() ?: 55f
                            onSave(name, startVal, targetVal)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CutePinkPrimary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Kaydet", color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun QuickRecordDialog(
    dateStr: String,
    initialWeight: Float,
    onDismiss: () -> Unit,
    onSave: (Float, Int, Int) -> Unit
) {
    var weight by remember { mutableStateOf(if (initialWeight > 0f) initialWeight.toString() else "") }
    var intake by remember { mutableStateOf("1500") }
    var burned by remember { mutableStateOf("300") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .shadow(8.dp, RoundedCornerShape(24.dp)),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CuteCatPaw(modifier = Modifier.size(50.dp))
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Bugünkü Verileri Gir 🐾",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = TextDark
                )
                Text(text = dateStr, fontSize = 12.sp, color = TextLight)

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = weight,
                    onValueChange = { weight = it },
                    label = { Text("Bugünkü Kilon (kg)") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = CutePinkPrimary),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = intake,
                    onValueChange = { intake = it },
                    label = { Text("Alınan Kalori (kcal)") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = CutePinkPrimary),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = burned,
                    onValueChange = { burned = it },
                    label = { Text("Yakılan Kalori (kcal)") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = CutePinkPrimary),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("İptal", color = TextDark)
                    }
                    Button(
                        onClick = {
                            val wVal = weight.toFloatOrNull() ?: 0f
                            val iVal = intake.toIntOrNull() ?: 0
                            val bVal = burned.toIntOrNull() ?: 0
                            if (wVal > 0f) {
                                onSave(wVal, iVal, bVal)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CutePinkPrimary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Kaydet", color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun CalendarQuickRecordDialog(
    dateStr: String,
    existingRecord: WeightRecord?,
    onDismiss: () -> Unit,
    onSave: (Float, Int, Int) -> Unit
) {
    var weight by remember { mutableStateOf(existingRecord?.weight?.toString() ?: "") }
    var intake by remember { mutableStateOf(existingRecord?.calorieIntake?.toString() ?: "") }
    var burned by remember { mutableStateOf(existingRecord?.calorieBurned?.toString() ?: "") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .shadow(8.dp, RoundedCornerShape(24.dp)),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CuteCatPaw(modifier = Modifier.size(50.dp))
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Post-it Veri Ekleme",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = TextDark
                )
                Text(text = "Tarih: $dateStr 🐾", fontSize = 12.sp, color = TextLight, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = weight,
                    onValueChange = { weight = it },
                    label = { Text("Kilo (kg)") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = CutePinkPrimary),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = intake,
                    onValueChange = { intake = it },
                    label = { Text("Alınan Kalori (kcal)") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = CutePinkPrimary),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = burned,
                    onValueChange = { burned = it },
                    label = { Text("Yakılan Kalori (kcal)") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = CutePinkPrimary),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("İptal", color = TextDark)
                    }
                    Button(
                        onClick = {
                            val wVal = weight.toFloatOrNull() ?: 0f
                            val iVal = intake.toIntOrNull() ?: 0
                            val bVal = burned.toIntOrNull() ?: 0
                            if (wVal > 0f) {
                                onSave(wVal, iVal, bVal)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CutePinkPrimary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Kaydet", color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun MealReminderSection(
    viewModel: DiyetViewModel
) {
    val reminders by viewModel.mealReminders.collectAsStateWithLifecycle()
    var selectedReminderForTimeEdit by remember { mutableStateOf<DiyetViewModel.MealReminder?>(null) }
    val context = LocalContext.current

    // Launcher for POST_NOTIFICATIONS permission
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            Toast.makeText(context, "Bildirim izni verildi! 🐾", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Öğün hatırlatıcılarını görebilmek için bildirim izni gereklidir. 😿", Toast.LENGTH_LONG).show()
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(4.dp, RoundedCornerShape(24.dp)),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.5.dp, CutePinkTertiary)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.NotificationsActive,
                    contentDescription = "Hatırlatıcılar",
                    tint = CutePinkPrimary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Patili Öğün Hatırlatıcıları 🔔🐾",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = TextDark
                )
            }
            
            Text(
                text = "Öğün saatlerinizi kaçırmayın! Saatleri ayarlayabilir, yanındaki pati butonu ile anında test bildirimi gönderebilirsiniz.",
                fontSize = 12.sp,
                color = TextLight,
                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
            )

            reminders.forEach { reminder ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .background(CutePinkTertiary.copy(alpha = 0.15f), RoundedCornerShape(16.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = reminder.name,
                                fontWeight = FontWeight.Bold,
                                color = TextDark,
                                fontSize = 14.sp
                            )
                            
                            // Time Display Button
                            TextButton(
                                onClick = { selectedReminderForTimeEdit = reminder },
                                contentPadding = PaddingValues(0.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Schedule,
                                    contentDescription = "Saat Seç",
                                    tint = CutePinkPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = String.format("%02d:%02d 🕒", reminder.hour, reminder.minute),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.sp,
                                    color = CutePinkPrimary
                                )
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Instant Test Button
                            IconButton(
                                onClick = {
                                    viewModel.triggerTestNotification(reminder.id)
                                },
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(CutePinkTertiary.copy(alpha = 0.5f), CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Pets,
                                    contentDescription = "Test Et",
                                    tint = TextDark,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            // Toggle Switch
                            Switch(
                                checked = reminder.isEnabled,
                                onCheckedChange = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        permissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                                    }
                                    viewModel.toggleMealReminder(reminder.id)
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = CutePinkPrimary,
                                    uncheckedThumbColor = TextLight,
                                    uncheckedTrackColor = CuteCreamSurface
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Bildirim: \"${reminder.defaultMessage}\"",
                        fontSize = 10.sp,
                        color = TextLight,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }

    if (selectedReminderForTimeEdit != null) {
        CuteTimePickerDialog(
            reminder = selectedReminderForTimeEdit!!,
            onDismiss = { selectedReminderForTimeEdit = null },
            onSave = { h, m ->
                viewModel.updateMealTime(selectedReminderForTimeEdit!!.id, h, m)
                selectedReminderForTimeEdit = null
            }
        )
    }
}

@Composable
fun CuteTimePickerDialog(
    reminder: DiyetViewModel.MealReminder,
    onDismiss: () -> Unit,
    onSave: (hour: Int, minute: Int) -> Unit
) {
    var hour by remember { mutableStateOf(reminder.hour) }
    var minute by remember { mutableStateOf(reminder.minute) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .shadow(8.dp, RoundedCornerShape(24.dp)),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CuteCatPaw(modifier = Modifier.size(48.dp))
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "${reminder.name} Saatini Ayarla 🐾",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = TextDark,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(20.dp))

                // Interactive Cute Number Pickers
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Hour picker
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(onClick = { hour = if (hour == 23) 0 else hour + 1 }) {
                            Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Arttır")
                        }
                        Text(
                            text = String.format("%02d", hour),
                            fontSize = 32.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextDark
                        )
                        IconButton(onClick = { hour = if (hour == 0) 23 else hour - 1 }) {
                            Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Azalt")
                        }
                    }

                    Text(
                        text = ":",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = TextDark,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )

                    // Minute picker
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(onClick = { minute = if (minute == 59) 0 else minute + 1 }) {
                            Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Arttır")
                        }
                        Text(
                            text = String.format("%02d", minute),
                            fontSize = 32.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextDark
                        )
                        IconButton(onClick = { minute = if (minute == 0) 59 else minute - 1 }) {
                            Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Azalt")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("İptal", color = TextDark)
                    }
                    Button(
                        onClick = { onSave(hour, minute) },
                        colors = ButtonDefaults.buttonColors(containerColor = CutePinkPrimary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Kaydet", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// --- ACHIEVEMENTS SCREEN & COMPONENT SUITE ---

@Composable
fun AchievementsScreen(
    viewModel: DiyetViewModel
) {
    val profile by viewModel.userProfile.collectAsStateWithLifecycle()
    val totalLost by viewModel.totalWeightLost.collectAsStateWithLifecycle()
    val bgMusicEnabled by viewModel.bgMusicEnabled.collectAsStateWithLifecycle()

    var selectedDetailBadge by remember { mutableStateOf<Badge?>(null) }

    val badges = viewModel.badgesList

    val unlockedBadgesCount = remember(badges, profile.xp, totalLost) {
        badges.count { badge ->
            if (badge.isXpBased) {
                profile.xp >= badge.threshold
            } else {
                totalLost >= badge.threshold
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CutePinkTertiary.copy(alpha = 0.2f))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- 1. OVERVIEW PROGRESS CARD ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "🏆 BAŞARI ANALİZİ 🏆",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = CutePinkPrimary
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Toplam Puan", fontSize = 12.sp, color = TextLight, fontWeight = FontWeight.Bold)
                            Text("${profile.xp} XP", fontSize = 20.sp, color = TextDark, fontWeight = FontWeight.ExtraBold)
                        }
                        Box(
                            modifier = Modifier
                                .width(1.dp)
                                .height(40.dp)
                                .background(Color.LightGray)
                        )
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Verilen Kilo", fontSize = 12.sp, color = TextLight, fontWeight = FontWeight.Bold)
                            Text(String.format("%.1f kg", totalLost), fontSize = 20.sp, color = TextDark, fontWeight = FontWeight.ExtraBold)
                        }
                        Box(
                            modifier = Modifier
                                .width(1.dp)
                                .height(40.dp)
                                .background(Color.LightGray)
                        )
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Kazanılan Rozet", fontSize = 12.sp, color = TextLight, fontWeight = FontWeight.Bold)
                            Text("$unlockedBadgesCount / 10", fontSize = 20.sp, color = TextDark, fontWeight = FontWeight.ExtraBold)
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Progress bar for overall collection
                    val progress = unlockedBadgesCount / 10f
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Rozet Koleksiyonu Tamamlama", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextDark)
                            Text("${(progress * 100).toInt()}%", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CutePinkPrimary)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = progress,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(10.dp)
                                .clip(RoundedCornerShape(5.dp)),
                            color = CutePinkPrimary,
                            trackColor = CutePinkTertiary
                        )
                    }
                }
            }
        }

        // --- 2. MUSIC & SETTINGS CARD ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(CutePinkTertiary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.MusicNote,
                                contentDescription = "Müzik",
                                tint = CutePinkPrimary
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Sakinleştirici Fon Müziği 🎹🎻",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextDark
                            )
                            Text(
                                text = "Piyano ve uzaktan gelen keman melodisi",
                                fontSize = 11.sp,
                                color = TextLight
                            )
                        }
                    }
                    Switch(
                        checked = bgMusicEnabled,
                        onCheckedChange = { viewModel.toggleBgMusic() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = CutePinkPrimary,
                            uncheckedThumbColor = Color.Gray,
                            uncheckedTrackColor = Color.LightGray
                        )
                    )
                }
            }
        }

        // --- 3. REPLAY 10KG CELEBRATION MANUALLY IF DESIRED ---
        item {
            val isCelebrationUnlocked = totalLost >= 10.0f
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(enabled = true) {
                        viewModel.trigger10KgCelebrationManual()
                    },
                colors = CardDefaults.cardColors(
                    containerColor = if (isCelebrationUnlocked) Color(0xFFFFF9C4) else Color(0xFFF5F5F5)
                ),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(
                    1.5.dp,
                    if (isCelebrationUnlocked) Color(0xFFFFD700) else Color.LightGray
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = if (isCelebrationUnlocked) "👑" else "🔒",
                            fontSize = 24.sp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "10 Kilo Kutlamasını Oynat 🎉",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isCelebrationUnlocked) TextDark else Color.Gray
                            )
                            Text(
                                text = if (isCelebrationUnlocked) 
                                    "Büyük milat animasyonu ve müziğini tekrar izle!" 
                                    else "Kilidi açmak için 10 kilo verme hedefine ulaşmalısın.",
                                fontSize = 11.sp,
                                color = TextLight
                            )
                        }
                    }
                    if (isCelebrationUnlocked) {
                        Icon(
                            imageVector = Icons.Default.PlayCircle,
                            contentDescription = "Oynat",
                            tint = CutePinkPrimary,
                            modifier = Modifier.size(32.dp)
                        )
                    } else {
                        // Demo trigger button for premium feel
                        TextButton(
                            onClick = { viewModel.trigger10KgCelebrationManual() }
                        ) {
                            Text("Test Et 🐾", color = CutePinkPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // --- 4. TITLE FOR BADGES ---
        item {
            Text(
                text = "Dijital Rozet Galerisi 🐾🎨",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = TextDark,
                modifier = Modifier.padding(start = 4.dp, top = 8.dp)
            )
        }

        // --- 5. ROZET LIST GRID REPLACEMENT ---
        // Displaying 10 badges elegantly as a structured series of card rows
        badges.forEach { badge ->
            val isUnlocked = if (badge.isXpBased) {
                profile.xp >= badge.threshold
            } else {
                totalLost >= badge.threshold
            }

            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedDetailBadge = badge },
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(
                        if (isUnlocked) 1.5.dp else 1.dp,
                        if (isUnlocked) CutePinkPrimary.copy(alpha = 0.5f) else Color.Transparent
                    ),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        BadgeIllustration(badgeId = badge.id, isUnlocked = isUnlocked)
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = badge.name,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isUnlocked) TextDark else Color.Gray
                                )
                                if (isUnlocked) {
                                    Text("🏆", fontSize = 14.sp)
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = badge.description,
                                fontSize = 11.sp,
                                color = TextLight,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            // Criteria badge
                            Row(
                                modifier = Modifier
                                    .background(
                                        if (isUnlocked) CutePinkTertiary.copy(alpha = 0.4f) else Color(0xFFEEEEEE),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .padding(horizontal = 8.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (isUnlocked) Icons.Default.CheckCircle else Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = if (isUnlocked) CutePinkPrimary else Color.Gray,
                                    modifier = Modifier.size(10.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isUnlocked) "Açıldı!" else "Kriter: ${badge.unlockCriteria}",
                                    fontSize = 10.sp,
                                    color = if (isUnlocked) TextDark else Color.Gray,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Detail dialog when user clicks a badge
    selectedDetailBadge?.let { badge ->
        val isUnlocked = if (badge.isXpBased) {
            profile.xp >= badge.threshold
        } else {
            totalLost >= badge.threshold
        }

        AchievementDetailDialog(
            badge = badge,
            isUnlocked = isUnlocked,
            onDismiss = { selectedDetailBadge = null }
        )
    }
}

@Composable
fun BadgeIllustration(badgeId: Int, isUnlocked: Boolean, modifier: Modifier = Modifier) {
    val alpha = if (isUnlocked) 1.0f else 0.35f
    val mainColor = if (isUnlocked) CutePinkPrimary else Color.Gray
    val accentColor = if (isUnlocked) CutePinkSecondary else Color.LightGray
    val goldColor = if (isUnlocked) Color(0xFFFFD700) else Color.Gray

    Box(
        modifier = modifier
            .size(72.dp)
            .background(
                if (isUnlocked) CutePinkTertiary.copy(alpha = 0.3f) else Color(0xFFF1F1F1),
                CircleShape
            )
            .border(
                2.dp,
                if (isUnlocked) goldColor else Color.LightGray,
                CircleShape
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(12.dp)) {
            val w = size.width
            val h = size.height

            when (badgeId) {
                1 -> { // Pati Başlangıcı: Cute pink paw
                    drawCircle(color = mainColor, radius = w * 0.25f, center = androidx.compose.ui.geometry.Offset(w * 0.5f, h * 0.58f), alpha = alpha)
                    drawCircle(color = accentColor, radius = w * 0.08f, center = androidx.compose.ui.geometry.Offset(w * 0.25f, h * 0.32f), alpha = alpha)
                    drawCircle(color = accentColor, radius = w * 0.1f, center = androidx.compose.ui.geometry.Offset(w * 0.42f, h * 0.22f), alpha = alpha)
                    drawCircle(color = accentColor, radius = w * 0.1f, center = androidx.compose.ui.geometry.Offset(w * 0.58f, h * 0.22f), alpha = alpha)
                    drawCircle(color = accentColor, radius = w * 0.08f, center = androidx.compose.ui.geometry.Offset(w * 0.75f, h * 0.32f), alpha = alpha)
                }
                2 -> { // Yavru Pati: sleeping kitten on a pillow
                    drawOval(color = Color(0xFFFF94B9), topLeft = androidx.compose.ui.geometry.Offset(w * 0.15f, h * 0.6f), size = androidx.compose.ui.geometry.Size(w * 0.7f, h * 0.3f), alpha = alpha * 0.8f)
                    drawCircle(color = Color(0xFFFFF0E0), radius = w * 0.22f, center = androidx.compose.ui.geometry.Offset(w * 0.5f, h * 0.48f), alpha = alpha)
                    drawLine(color = Color.DarkGray, start = androidx.compose.ui.geometry.Offset(w * 0.38f, h * 0.48f), end = androidx.compose.ui.geometry.Offset(w * 0.45f, h * 0.48f), strokeWidth = 2.dp.toPx(), alpha = alpha)
                    drawLine(color = Color.DarkGray, start = androidx.compose.ui.geometry.Offset(w * 0.55f, h * 0.48f), end = androidx.compose.ui.geometry.Offset(w * 0.62f, h * 0.48f), strokeWidth = 2.dp.toPx(), alpha = alpha)
                }
                3 -> { // Meraklı Kedi: peeking cat from a box
                    drawRect(color = Color(0xFFD2B48C), topLeft = androidx.compose.ui.geometry.Offset(w * 0.2f, h * 0.55f), size = androidx.compose.ui.geometry.Size(w * 0.6f, h * 0.4f), alpha = alpha)
                    drawCircle(color = Color(0xFFECEFF1), radius = w * 0.24f, center = androidx.compose.ui.geometry.Offset(w * 0.5f, h * 0.42f), alpha = alpha)
                    val leftEar = androidx.compose.ui.graphics.Path().apply {
                        moveTo(w * 0.3f, h * 0.25f)
                        lineTo(w * 0.22f, h * 0.08f)
                        lineTo(w * 0.4f, h * 0.22f)
                        close()
                    }
                    val rightEar = androidx.compose.ui.graphics.Path().apply {
                        moveTo(w * 0.7f, h * 0.25f)
                        lineTo(w * 0.78f, h * 0.08f)
                        lineTo(w * 0.6f, h * 0.22f)
                        close()
                    }
                    drawPath(leftEar, color = Color(0xFFECEFF1), alpha = alpha)
                    drawPath(rightEar, color = Color(0xFFECEFF1), alpha = alpha)
                }
                4 -> { // Gurme Dedektif: cat with chef hat
                    drawCircle(color = Color(0xFFFFE0B2), radius = w * 0.25f, center = androidx.compose.ui.geometry.Offset(w * 0.5f, h * 0.6f), alpha = alpha)
                    drawCircle(color = Color.White, radius = w * 0.15f, center = androidx.compose.ui.geometry.Offset(w * 0.5f, h * 0.32f), alpha = alpha)
                    drawCircle(color = Color.White, radius = w * 0.12f, center = androidx.compose.ui.geometry.Offset(w * 0.38f, h * 0.36f), alpha = alpha)
                    drawCircle(color = Color.White, radius = w * 0.12f, center = androidx.compose.ui.geometry.Offset(w * 0.62f, h * 0.36f), alpha = alpha)
                    drawRect(color = Color.White, topLeft = androidx.compose.ui.geometry.Offset(w * 0.38f, h * 0.4f), size = androidx.compose.ui.geometry.Size(w * 0.24f, h * 0.12f), alpha = alpha)
                }
                5 -> { // Atletik Mırr: cat with dumbbells
                    drawCircle(color = Color(0xFFB0BEC5), radius = w * 0.25f, center = androidx.compose.ui.geometry.Offset(w * 0.5f, h * 0.5f), alpha = alpha)
                    drawLine(color = Color.DarkGray, start = androidx.compose.ui.geometry.Offset(w * 0.1f, h * 0.7f), end = androidx.compose.ui.geometry.Offset(w * 0.9f, h * 0.7f), strokeWidth = 3.dp.toPx(), alpha = alpha)
                    drawCircle(color = mainColor, radius = w * 0.1f, center = androidx.compose.ui.geometry.Offset(w * 0.15f, h * 0.7f), alpha = alpha)
                    drawCircle(color = mainColor, radius = w * 0.1f, center = androidx.compose.ui.geometry.Offset(w * 0.85f, h * 0.7f), alpha = alpha)
                }
                6 -> { // Süperstar Pati: cat with crown & cape
                    val cape = androidx.compose.ui.graphics.Path().apply {
                        moveTo(w * 0.5f, h * 0.55f)
                        lineTo(w * 0.1f, h * 0.95f)
                        lineTo(w * 0.9f, h * 0.95f)
                        close()
                    }
                    drawPath(cape, color = Color(0xFFE53935), alpha = alpha)
                    drawCircle(color = Color(0xFFFFF3E0), radius = w * 0.23f, center = androidx.compose.ui.geometry.Offset(w * 0.5f, h * 0.48f), alpha = alpha)
                    val crown = androidx.compose.ui.graphics.Path().apply {
                        moveTo(w * 0.35f, h * 0.28f)
                        lineTo(w * 0.38f, h * 0.12f)
                        lineTo(w * 0.5f, h * 0.22f)
                        lineTo(w * 0.62f, h * 0.12f)
                        lineTo(w * 0.65f, h * 0.28f)
                        close()
                    }
                    drawPath(crown, color = goldColor, alpha = alpha)
                }
                7 -> { // Hafif Pati: cat with balloon
                    drawLine(color = Color.Gray, start = androidx.compose.ui.geometry.Offset(w * 0.3f, h * 0.62f), end = androidx.compose.ui.geometry.Offset(w * 0.68f, h * 0.28f), strokeWidth = 1.dp.toPx(), alpha = alpha)
                    drawCircle(color = Color(0xFFFF4081), radius = w * 0.16f, center = androidx.compose.ui.geometry.Offset(w * 0.68f, h * 0.22f), alpha = alpha)
                    drawCircle(color = Color(0xFFF5F5F5), radius = w * 0.22f, center = androidx.compose.ui.geometry.Offset(w * 0.32f, h * 0.68f), alpha = alpha)
                }
                8 -> { // Tüy Siklet: feather cat
                    drawCircle(color = Color(0xFFFFEBEB), radius = w * 0.25f, center = androidx.compose.ui.geometry.Offset(w * 0.5f, h * 0.55f), alpha = alpha)
                    val feather = androidx.compose.ui.graphics.Path().apply {
                        moveTo(w * 0.5f, h * 0.32f)
                        quadraticTo(w * 0.42f, h * 0.12f, w * 0.52f, h * 0.05f)
                        quadraticTo(w * 0.58f, h * 0.18f, w * 0.5f, h * 0.32f)
                        close()
                    }
                    drawPath(feather, color = Color(0xFF00ACC1), alpha = alpha)
                }
                9 -> { // Formda Miyav: cat stretching
                    drawOval(color = Color(0xFFF3E5F5), topLeft = androidx.compose.ui.geometry.Offset(w * 0.2f, h * 0.42f), size = androidx.compose.ui.geometry.Size(w * 0.52f, h * 0.32f), alpha = alpha)
                    drawCircle(color = Color(0xFFE1BEE7), radius = w * 0.16f, center = androidx.compose.ui.geometry.Offset(w * 0.72f, h * 0.45f), alpha = alpha)
                }
                10 -> { // Efsanevi Kaplan: lion/tiger cat
                    for (angle in 0 until 360 step 45) {
                        val rad = Math.toRadians(angle.toDouble())
                        val cx = (w * 0.5f + (w * 0.24f * Math.cos(rad))).toFloat()
                        val cy = (h * 0.52f + (h * 0.24f * Math.sin(rad))).toFloat()
                        drawCircle(color = Color(0xFFFFB300), radius = w * 0.13f, center = androidx.compose.ui.geometry.Offset(cx, cy), alpha = alpha)
                    }
                    drawCircle(color = Color(0xFFFFE082), radius = w * 0.22f, center = androidx.compose.ui.geometry.Offset(w * 0.5f, h * 0.52f), alpha = alpha)
                    val bigCrown = androidx.compose.ui.graphics.Path().apply {
                        moveTo(w * 0.35f, h * 0.32f)
                        lineTo(w * 0.38f, h * 0.15f)
                        lineTo(w * 0.5f, h * 0.24f)
                        lineTo(w * 0.62f, h * 0.15f)
                        lineTo(w * 0.65f, h * 0.32f)
                        close()
                    }
                    drawPath(bigCrown, color = goldColor, alpha = alpha)
                }
            }
        }
    }
}

@Composable
fun FullScreen10KgCelebration(
    viewModel: DiyetViewModel
) {
    val showCelebration by viewModel.show10KgCelebration.collectAsStateWithLifecycle()

    if (showCelebration) {
        Dialog(
            onDismissRequest = { viewModel.dismiss10KgCelebration() }
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.85f))
            ) {
                // Background twinkling stars or full-screen confetti
                CuteConfetti(modifier = Modifier.fillMaxSize())

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    // Huge golden rotating/bouncing crown
                    val infiniteTransition = rememberInfiniteTransition(label = "crown")
                    val rotation by infiniteTransition.animateFloat(
                        initialValue = -10f,
                        targetValue = 10f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(1200, easing = LinearEasing),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "rotation"
                    )
                    
                    val scale by infiniteTransition.animateFloat(
                        initialValue = 0.95f,
                        targetValue = 1.15f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(1000, easing = FastOutSlowInEasing),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "scale"
                    )

                    Box(
                        modifier = Modifier
                            .graphicsLayer {
                                rotationZ = rotation
                                scaleX = scale
                                scaleY = scale
                            }
                            .size(140.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        BadgeIllustration(badgeId = 10, isUnlocked = true, modifier = Modifier.size(130.dp))
                    }

                    Spacer(modifier = Modifier.height(32.dp))

                    Text(
                        text = "İNANILMAZ BİR BAŞARI! 👑🦁🎉",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFFFFD700), // Gold
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Yağmur tam 10 KİLO verdi! 🐾✨",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Sakin piyano ve keman tınıları eşliğinde bu tarihi anı kutluyoruz! Sen tam bir Efsanevi Kaplan'sın, mırrr! Muhteşem disiplinin ve iraden için patilerimiz seni saygıyla selamlıyor! 🐾💖👑",
                        fontSize = 15.sp,
                        color = Color.White.copy(alpha = 0.9f),
                        textAlign = TextAlign.Center,
                        lineHeight = 22.sp,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )

                    Spacer(modifier = Modifier.height(36.dp))

                    Button(
                        onClick = { viewModel.dismiss10KgCelebration() },
                        colors = ButtonDefaults.buttonColors(containerColor = CutePinkPrimary),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                    ) {
                        Text("Mükemmel, Miyav! 🐾💖", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AchievementDetailDialog(
    badge: Badge,
    isUnlocked: Boolean,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = Color.White,
            tonalElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .border(2.dp, if (isUnlocked) CutePinkPrimary else Color.LightGray, RoundedCornerShape(28.dp))
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Interactive floating badge
                BadgeIllustration(badgeId = badge.id, isUnlocked = isUnlocked, modifier = Modifier.size(96.dp))

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = badge.name,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextDark,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Locked/Unlocked subtitle
                Row(
                    modifier = Modifier
                        .background(
                            if (isUnlocked) CutePinkTertiary else Color(0xFFEEEEEE),
                            RoundedCornerShape(12.dp)
                        )
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isUnlocked) "KAZANILDI! 🏆🐾" else "🔒 KİLİTLİ",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isUnlocked) CutePinkPrimary else Color.Gray
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = badge.description,
                    fontSize = 14.sp,
                    color = TextLight,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )

                if (isUnlocked) {
                    Spacer(modifier = Modifier.height(20.dp))
                    
                    // Cute kitty talk balloon
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CutePinkTertiary.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                            .padding(16.dp)
                    ) {
                        Text(
                            text = badge.quote,
                            fontSize = 13.sp,
                            color = TextDark,
                            textAlign = TextAlign.Center,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                            lineHeight = 18.sp,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Kilidini açmak için gereken: ${badge.unlockCriteria}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = CutePinkPrimary,
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = CutePinkPrimary),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Harika! 🐾", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun FishStealingAnimation(
    visible: Boolean,
    onAnimationEnd: () -> Unit
) {
    if (!visible) return

    val animProgress = remember { Animatable(0f) }

    LaunchedEffect(visible) {
        animProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 2000, easing = FastOutSlowInEasing)
        )
        kotlinx.coroutines.delay(300)
        onAnimationEnd()
    }

    val progress = animProgress.value

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp)
            .background(Color(0xFFFFFDE7), RoundedCornerShape(16.dp))
            .border(1.5.dp, Color(0xFFFFD54F), RoundedCornerShape(16.dp))
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // 1. Draw a plate in the center-left
            val plateX = w * 0.35f
            val plateY = h * 0.65f
            val plateRadiusW = w * 0.18f
            val plateRadiusH = h * 0.08f

            // Plate outer
            drawOval(
                color = Color(0xFFE0F7FA),
                topLeft = Offset(plateX - plateRadiusW, plateY - plateRadiusH),
                size = Size(plateRadiusW * 2, plateRadiusH * 2)
            )
            // Plate inner rim
            drawOval(
                color = Color.White,
                topLeft = Offset(plateX - plateRadiusW * 0.8f, plateY - plateRadiusH * 0.8f),
                size = Size(plateRadiusW * 1.6f, plateRadiusH * 1.6f),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx())
            )

            // 2. Draw a delicious fish bone on the plate
            val fishStolenProgress = if (progress > 0.5f) (progress - 0.5f) / 0.5f else 0f
            val fishX = plateX + (w * 0.45f - plateX) * fishStolenProgress
            val fishY = plateY + (h * 0.2f - plateY) * fishStolenProgress
            val fishScale = 1f - fishStolenProgress * 0.3f

            if (progress < 0.95f) {
                val fx = fishX
                val fy = fishY - h * 0.05f

                // Fish head (triangle)
                val headPath = androidx.compose.ui.graphics.Path().apply {
                    moveTo(fx - 24.dp.toPx() * fishScale, fy)
                    lineTo(fx - 12.dp.toPx() * fishScale, fy - 8.dp.toPx() * fishScale)
                    lineTo(fx - 12.dp.toPx() * fishScale, fy + 8.dp.toPx() * fishScale)
                    close()
                }
                drawPath(headPath, Color(0xFF90A4AE))

                // Spine bone line
                drawLine(
                    color = Color(0xFF90A4AE),
                    start = Offset(fx - 12.dp.toPx() * fishScale, fy),
                    end = Offset(fx + 24.dp.toPx() * fishScale, fy),
                    strokeWidth = 3.dp.toPx() * fishScale
                )

                // Vertical bones
                for (offset in listOf(-4, 4, 12)) {
                    val bx = fx + offset.dp.toPx() * fishScale
                    drawLine(
                        color = Color(0xFF90A4AE),
                        start = Offset(bx, fy - 10.dp.toPx() * fishScale),
                        end = Offset(bx, fy + 10.dp.toPx() * fishScale),
                        strokeWidth = 2.dp.toPx() * fishScale
                    )
                }

                // Fish tail
                val tailPath = androidx.compose.ui.graphics.Path().apply {
                    moveTo(fx + 24.dp.toPx() * fishScale, fy)
                    lineTo(fx + 32.dp.toPx() * fishScale, fy - 10.dp.toPx() * fishScale)
                    lineTo(fx + 32.dp.toPx() * fishScale, fy + 10.dp.toPx() * fishScale)
                    close()
                }
                drawPath(tailPath, Color(0xFF90A4AE))
            }

            // 3. Draw cat paw reaching out from the right to steal the fish!
            val pawX = if (progress < 0.5f) {
                val p = progress / 0.5f
                w * 0.9f - (w * 0.9f - plateX) * p
            } else {
                val p = (progress - 0.5f) / 0.5f
                plateX + (w * 0.9f - plateX) * p
            }
            val pawY = h * 0.65f

            // Paw arm sleeve
            drawLine(
                color = Color(0xFFFFFFFF),
                start = Offset(w * 0.95f, h * 0.65f),
                end = Offset(pawX, pawY),
                strokeWidth = 24.dp.toPx()
            )
            // Sleeve outlines
            drawLine(
                color = Color(0xFF333333),
                start = Offset(w * 0.95f, h * 0.65f - 12.dp.toPx()),
                end = Offset(pawX, pawY - 12.dp.toPx()),
                strokeWidth = 2.dp.toPx()
            )
            drawLine(
                color = Color(0xFF333333),
                start = Offset(w * 0.95f, h * 0.65f + 12.dp.toPx()),
                end = Offset(pawX, pawY + 12.dp.toPx()),
                strokeWidth = 2.dp.toPx()
            )

            // Cat Paw main pad
            drawCircle(
                color = Color.White,
                radius = 16.dp.toPx(),
                center = Offset(pawX, pawY)
            )
            drawCircle(
                color = Color(0xFF333333),
                radius = 16.dp.toPx(),
                center = Offset(pawX, pawY),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx())
            )

            // Pink paw pad inside
            drawCircle(
                color = Color(0xFFFF80AB),
                radius = 8.dp.toPx(),
                center = Offset(pawX, pawY + 2.dp.toPx())
            )

            // Pink toes
            drawCircle(color = Color(0xFFFF80AB), radius = 3.dp.toPx(), center = Offset(pawX - 8.dp.toPx(), pawY - 8.dp.toPx()))
            drawCircle(color = Color(0xFFFF80AB), radius = 3.dp.toPx(), center = Offset(pawX, pawY - 11.dp.toPx()))
            drawCircle(color = Color(0xFFFF80AB), radius = 3.dp.toPx(), center = Offset(pawX + 8.dp.toPx(), pawY - 8.dp.toPx()))
        }
        
        Text(
            text = "Hoppala! Balık gitti! 🐾🐟",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFE65100),
            modifier = Modifier.align(Alignment.TopCenter)
        )
    }
}

@Composable
fun UpdateNotesDialog(
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        val infiniteTransition = rememberInfiniteTransition(label = "update_bounce")
        val scale by infiniteTransition.animateFloat(
            initialValue = 0.95f,
            targetValue = 1.05f,
            animationSpec = infiniteRepeatable(
                animation = tween(1200, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "scale"
        )

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .graphicsLayer(scaleX = scale, scaleY = scale)
                .shadow(12.dp, RoundedCornerShape(24.dp)),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(2.dp, CutePinkPrimary)
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "🐾 GÜNCELLEME NOTLARI (v2.0) 🐾",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp,
                    color = CutePinkPrimary,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Cute graphic representation of both cats
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        PixelArtMilka(modifier = Modifier.size(60.dp))
                        Text("Milka 🤍", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextDark)
                    }
                    Text("❤️", fontSize = 24.sp)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        PixelArtPufpuf(modifier = Modifier.size(60.dp))
                        Text("Pufpuf 🩶", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextDark)
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Merhaba Yağmur! Senin için hazırladığımız muhteşem 2.0 güncelleme paketi yayında! İşte yenilikler:",
                    fontSize = 13.sp,
                    color = TextDark,
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(12.dp))

                val notesList = listOf(
                    "💬 Canlı Diyalog Sistemi: Pufpuf ve Milka artık 30 saniyede bir ekranın altında belirecek ve karakterlerine has konuşmalar yapacaklar!",
                    "🏆 25 Özel Başarı Rozeti: Diyet yolculuğunda gösterdiğin üstün başarı ve XP birikimine göre yepyeni kilitlenebilir başarılar eklendi!",
                    "💧 Su Hatırlatıcıları: Gün boyu patilerini taze tutmak için her 2 saatte bir kedilerinden canlandırıcı su içme uyarıları alacaksın!",
                    "💃 Disiplin Ödülü Dansı: Eğer günü hiç kaçamaksız kapatırsan, akşam saat 20:00'de kedilerin seninle kutlama dansı yapacak!",
                    "🎶 Geliştirilmiş Hafiflik: Arka plandaki müzik sistemi tamamen hafifletildi ve kesintisiz, huzur dolu yeni bir piyano tınısına kavuştu!"
                )

                notesList.forEach { note ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = CutePinkTertiary.copy(alpha = 0.15f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = note,
                            fontSize = 12.sp,
                            color = TextDark,
                            modifier = Modifier.padding(10.dp),
                            fontWeight = FontWeight.Normal
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = CutePinkPrimary),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Harika, Başlayalım! 🚀🐾", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun DancingCatsCelebrationDialog(
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        val infiniteTransition = rememberInfiniteTransition(label = "dancing_cats")
        
        // Animated bounce offset for dancing effect
        val bounceOffset1 by infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = -15f,
            animationSpec = infiniteRepeatable(
                animation = tween(400, easing = FastOutLinearInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "bounce1"
        )
        val bounceOffset2 by infiniteTransition.animateFloat(
            initialValue = -15f,
            targetValue = 0f,
            animationSpec = infiniteRepeatable(
                animation = tween(400, easing = FastOutLinearInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "bounce2"
        )

        val rotation by infiniteTransition.animateFloat(
            initialValue = -8f,
            targetValue = 8f,
            animationSpec = infiniteRepeatable(
                animation = tween(500, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "rotation"
        )

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .shadow(16.dp, RoundedCornerShape(28.dp)),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(28.dp),
            border = BorderStroke(3.dp, CutePinkPrimary)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "💃 KUSURSUZ DİSİPLİN DANSI 💃",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp,
                    color = CutePinkPrimary,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Bugün hiç kaçamak yapmadın! İşte Milka ve Pufpuf senin için dans ediyor!",
                    fontSize = 12.sp,
                    color = TextLight,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(24.dp))

                // Dancing cats animation container
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.Bottom
                ) {
                    // Milka dancing
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.offset(y = bounceOffset1.dp)
                    ) {
                        Box(contentAlignment = Alignment.TopCenter) {
                            // Speech balloon for Milka
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = CutePinkTertiary.copy(alpha = 0.2f)),
                                modifier = Modifier
                                    .padding(bottom = 65.dp)
                                    .widthIn(max = 120.dp)
                            ) {
                                Text(
                                    "Kaçamaksız gün mü? İnanamıyorum tatlış, dans vakti! 😹💃",
                                    fontSize = 9.sp,
                                    lineHeight = 11.sp,
                                    modifier = Modifier.padding(6.dp),
                                    textAlign = TextAlign.Center,
                                    color = TextDark
                                )
                            }
                            PixelArtMilka(
                                modifier = Modifier
                                    .size(70.dp)
                                    .rotate(rotation)
                                    .padding(top = 20.dp)
                            )
                        }
                        Text("Milka 🤍", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextDark)
                    }

                    // Pufpuf dancing
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.offset(y = bounceOffset2.dp)
                    ) {
                        Box(contentAlignment = Alignment.TopCenter) {
                            // Speech balloon for Pufpuf
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = CutePinkTertiary.copy(alpha = 0.2f)),
                                modifier = Modifier
                                    .padding(bottom = 65.dp)
                                    .widthIn(max = 120.dp)
                            ) {
                                Text(
                                    "Harika irade Yağmur! Seninle gurur duyuyorum mırrr! 🩶🏆",
                                    fontSize = 9.sp,
                                    lineHeight = 11.sp,
                                    modifier = Modifier.padding(6.dp),
                                    textAlign = TextAlign.Center,
                                    color = TextDark
                                )
                            }
                            PixelArtPufpuf(
                                modifier = Modifier
                                    .size(70.dp)
                                    .rotate(-rotation)
                                    .padding(top = 20.dp)
                            )
                        }
                        Text("Pufpuf 🩶", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextDark)
                    }
                }

                Spacer(modifier = Modifier.height(30.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = CutePinkPrimary),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Kedilerimle Dansa Devam! ✨🐾", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun BadgeUnlockCelebrationDialog(
    badge: Badge,
    onDismiss: () -> Unit
) {
    LaunchedEffect(badge) {
        com.example.util.AmbientSynth.playFanfare()
    }

    Dialog(onDismissRequest = onDismiss) {
        val infiniteTransition = rememberInfiniteTransition(label = "badge_bounce")
        val scale by infiniteTransition.animateFloat(
            initialValue = 0.96f,
            targetValue = 1.04f,
            animationSpec = infiniteRepeatable(
                animation = tween(800, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "badgeScale"
        )

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .graphicsLayer(scaleX = scale, scaleY = scale)
                .shadow(16.dp, RoundedCornerShape(28.dp)),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(28.dp),
            border = BorderStroke(3.dp, Color(0xFFFFD700)) // Gold border
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "🏆 ROZET KAZANILDI! 🏆",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp,
                    color = Color(0xFFD4AF37), // Gold color
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Beautiful Glowing Trophy Representation
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .background(Color(0xFFFFF9C4), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("🏆", fontSize = 56.sp)
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = badge.name,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 22.sp,
                    color = TextDark,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = badge.description,
                    fontSize = 13.sp,
                    color = TextLight,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Dialogue Bubble from the Corresponding Cat
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CutePinkTertiary.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val isMilkaQuote = badge.id % 2 != 0
                        if (isMilkaQuote) {
                            PixelArtMilka(modifier = Modifier.size(50.dp))
                        } else {
                            PixelArtPufpuf(modifier = Modifier.size(50.dp))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = badge.quote,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextDark,
                            lineHeight = 16.sp,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD4AF37)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Harika! Rozeti Koleksiyona Ekle 🐾", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
