package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class DiyetViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: DiyetRepository
    private val prefs = application.getSharedPreferences("patili_diyet_prefs", android.content.Context.MODE_PRIVATE)

    private val _bgMusicEnabled = MutableStateFlow(prefs.getBoolean("bg_music_enabled", true))
    val bgMusicEnabled: StateFlow<Boolean> = _bgMusicEnabled.asStateFlow()

    // 25 Custom Badges System
    val badgesList = listOf(
        Badge(1, "Pati Başlangıcı", "Sağlık ve zindelik yolculuğuna ilk adımı attın! Patiler seninle gurur duyuyor.", "Sürekli aktif kalmak ve günlüğe ilk adımını atmak.", true, 0f, "Miyav! Bu harika maceraya başladığın için çok mutluyum, patilerimiz daima ileriye gitmeli! 🐾💖"),
        Badge(2, "Yavru Pati", "Ufak adımlarla büyük farklar yaratıyorsun! İlk XP eşiğini geçtin.", "100 XP kazanmak.", true, 100f, "Mırrr... İlk ödülünü kaptın tatlışım! Yavru bir pati gibi hızlıca büyüyüp güçleniyorsun! 🐱🌸"),
        Badge(3, "Meraklı Kedi", "Diyet günlüğünü her gün merakla takip ediyor, istatistiklerini titizlikle inceliyorsun.", "200 XP kazanmak.", true, 200f, "Merak kediyi formda tutar! Her detayı mırıldayarak takip etmene bayılıyorum, miyav! 📦😻"),
        Badge(4, "Gurme Dedektif", "Yediğin her öğünü, aldığın kalorileri bir dedektif gibi kusursuzca takip ediyorsun.", "300 XP kazanmak.", true, 300f, "Miyav! Şef şapkamı senin için taktım. Kalorileri ve besinleri harika dengeliyorsun gurme dostum! 🍳🕵️‍♂️🐾"),
        Badge(5, "Atletik Mırr", "Fiziksel aktivitelerini hiç aksatmadan sürdürüyor, harika bir disiplin sergiliyorsun.", "400 XP kazanmak.", true, 400f, "Patiler havaya, squatlar aşağıya! Egzersiz bandımı senin için bağladım, harika bir kondisyon! 🏋️‍♀️🐈✨"),
        Badge(6, "Süperstar Pati", "Uygulamanın en sadık ve en ilham verici kahramanısın! Tam bir rol modelsin.", "600 XP kazanmak.", true, 600f, "Pelerinimi ve tacımı kuşanıp senin önünde saygıyla eğiliyorum Yağmur! Sen gerçek bir süperstarsın! 👑🦸‍♀️🐾"),
        Badge(7, "Kararlı Patiler", "İstikrar abidesi kedi dostumuz! Diyetini bozmadan devam eden özel şampiyon.", "800 XP kazanmak.", true, 800f, "Miyav! Kararlılığın karşısında asaletimle eğiliyorum. Sen tam bir şampiyonsun! 🤍🐾"),
        Badge(8, "Diyet Şampiyonu", "Büyük bir azimle hedefe ilerleyen örnek diyet kraliçesi.", "1000 XP kazanmak.", true, 1000f, "Muhteşem! 1000 XP kulübüne hoş geldin Yağmur! Sana özel bir somon ziyafeti hazırlamalıyım, mırrr! 🐟😻"),
        Badge(9, "Kusursuz Takipçi", "Öğün ve kalori detaylarını bir an bile kaçırmayan keskin gözlü kedi.", "1200 XP kazanmak.", true, 1200f, "Miyav! Gözlerim kamaşıyor. Bu kadar kusursuz bir takip ancak asil bir kediye yakışırdı! ✨🐾"),
        Badge(10, "Zarif Adımlar", "Zarafetiyle tüm gözleri üzerine çeken, her gün hafifleyen asil kedi.", "1500 XP kazanmak.", true, 1500f, "Süzülerek yürüyüşün, pürüzsüz disiplinin... Karşında mırıldanarak saygıyla eğiliyorum! 🤍🧘‍♀️"),
        Badge(11, "Pati Efendisi", "Uygulamadaki tüm patilere liderlik eden yüce disiplin koçu.", "2000 XP kazanmak.", true, 2000f, "Miyav! Artık sen de bir pati efendisisin. Tüm diyet klanı senin başarını konuşuyor! 👑🐾"),
        Badge(12, "Mitolojik Kaplan", "Diyet dünyasının en efsanevi, en ulaşılamaz, en muazzam kaplanı!", "3000 XP kazanmak.", true, 3000f, "İNANILMAZ! 3000 XP! Sen artık bir kaplansın, kükremen tüm diyet düşmanlarını korkutuyor! 🐯🏅🎉"),
        
        Badge(13, "Hafif Pati", "İlk hafifleme adımı! 200 gramlık kilo kaybı ile yolculuk resmen tescillendi.", "En az 200 gram (0.2 kg) vermek.", false, 0.2f, "Miyav! Bir tüy gibi havada uçtuğunu hissediyor musun? İlk yarım kilo patilerimize feda olsun! 🎈🐾"),
        Badge(14, "İlk Çeyrek", "0.5 kg vermeyi başararak harika bir motivasyon kazandın.", "En az 0.5 kg vermek.", false, 0.5f, "Yarım kilocuk gitti bile! Yağmur, pürüzsüz duruşunla harikalar yaratıyorsun tatlış! 🌸🐈"),
        Badge(15, "Yarım Kilo Elveda", "Tam 1 kilo kaybederek vücudundaki değişimin kapılarını araladın.", "En az 1.0 kg vermek.", false, 1.0f, "Güle güle bir kilo! Milka bu kiloyla ancak iki gün idare ederdi, sen süper gidiyorsun! 🤍🐾"),
        Badge(16, "Tüy Siklet", "Hafiflik rüzgarları esiyor! Tam 2 kilo vererek inanılmaz bir ilerleme kaydettin.", "En az 2.0 kg vermek.", false, 2.0f, "Mırrr... Bir tüy kadar narin, bir kedi gibi çevik ve mutlusun! Harika gidiyoruz tatlış! 🪶😻"),
        Badge(17, "Kuş Gibi", "Tam 3 kilo vererek adeta yerçekimine meydan okuyorsun.", "En az 3.0 kg vermek.", false, 3.0f, "Miyav! Yerçekimi artık sana sökmez. Kuş gibi hafifledin Yağmur! 🕊️🐾"),
        Badge(18, "Gözle Görülür Değişim", "Tam 4 kilo vererek harika bir fitliğe kavuştun, herkes seni konuşuyor.", "En az 4.0 kg vermek.", false, 4.0f, "İnanılmaz! Herkes sana bakıp iç geçiriyor Yağmur! Formun göz kamaştırıyor! 🤍✨"),
        Badge(19, "Formda Miyav", "Vücudundaki büyük değişimi herkes fark ediyor! Tam 5 kilo vererek sınırları aştın.", "En az 5.0 kg vermek.", false, 5.0f, "Şu zarafete, şu fit duruşa bak! Tüm mahallenin kedileri senin bu harika formunu konuşuyor, miyav! 🐾🧘‍♀️💖"),
        Badge(20, "Muhteşem Altı", "Tam 6 kilo kaybederek azmin ve sabrın muazzam zaferini ilan ettin.", "En az 6.0 kg vermek.", false, 6.0f, "Disiplin koçun Pufpuf bu harika 6 kiloluk kayıp karşısında saygıyla eğiliyor! 🩶🏆"),
        Badge(21, "Yedi Tepe", "Diyet dağlarının yedi tepesini de aştın! 7 kilo hafifleme başarısı.", "En az 7.0 kg vermek.", false, 7.0f, "Miyav! Yedi tepenin fatihi Yağmur! Bu muhteşem azmin karşısında eriyoruz! 🤍🌸"),
        Badge(22, "Süper Hafif", "Tam 8 kilo vererek hayal bile edilemeyen bir hafifliğe ulaştın.", "En az 8.0 kg vermek.", false, 8.0f, "Harika! 8 kilo hafiflik... Artık bulutların üstünde seksek oynayabilirsin tatlışım! 🐈✨"),
        Badge(23, "Bulutların Üstünde", "Tam 9 kilo kaybederek neredeyse sıfır yerçekimi moduna geçtin.", "En az 9.0 kg vermek.", false, 9.0f, "Mırrr... Bulutlar yatağın olsun Yağmur. 9 kiloluk bu efsanevi kayıp muazzam bir başarı! ☁️🤍"),
        Badge(24, "Efsanevi Kaplan", "İNANILMAZ! Tam 10 Kilo vererek adını altın harflerle yazdırdın. Sen bir şampiyonsun!", "En az 10.0 kg vermek.", false, 10.0f, "Kraliyet aslanı/kaplanı kükrüyor! 10 KİLO kayıp! Disiplinin, sabrın ve bu muazzam başarın önünde mırıldayarak şapka çıkartıyorum! 🐾👑🦁🏅🎉"),
        Badge(25, "Ulaşılamaz Zirve", "Tam 12 kilo vererek diyet evreninin ulaşılamaz zirvesine adını yazdırdın!", "En az 12.0 kg vermek.", false, 12.0f, "Aman tanrım! 12 Kilo! Sen artık diyet evreninin tanrıçasısın Yağmur! Önünde mırıldanarak secde ediyorum! 👑🐾🏆✨")
    )

    private val _newlyUnlockedBadge = MutableStateFlow<Badge?>(null)
    val newlyUnlockedBadge: StateFlow<Badge?> = _newlyUnlockedBadge.asStateFlow()

    fun clearNewlyUnlockedBadge() {
        _newlyUnlockedBadge.value = null
    }

    // Database Flows
    val weightRecords: StateFlow<List<WeightRecord>>
    val bodyMeasurements: StateFlow<List<BodyMeasurement>>
    val userProfile: StateFlow<UserProfile>
    val totalWeightLost: StateFlow<Float>

    // Post-it Wall Calendar Selection State
    private val _selectedYear = MutableStateFlow(Calendar.getInstance().get(Calendar.YEAR))
    val selectedYear: StateFlow<Int> = _selectedYear.asStateFlow()

    private val _selectedMonth = MutableStateFlow(Calendar.getInstance().get(Calendar.MONTH) + 1) // 1-12
    val selectedMonth: StateFlow<Int> = _selectedMonth.asStateFlow()

    // Animation & Celebration State
    private val _showConfetti = MutableStateFlow(false)
    val showConfetti: StateFlow<Boolean> = _showConfetti.asStateFlow()

    private val _show10KgCelebration = MutableStateFlow(false)
    val show10KgCelebration: StateFlow<Boolean> = _show10KgCelebration.asStateFlow()

    private val catPhrases = listOf(
        "Miyav! Harika gidiyorsun Yağmur, patilerim seni alkışlıyor! 😻",
        "Pati dostun seninle gurur duyuyor! Kilo vermen tam bir mucize, miyav! 🐾💖",
        "Mırrr... Kendini çok hafiflemiş hissediyorsun değil mi? Devam et tatlışım! 🐈",
        "Süperstar Yağmur! Hedefe doğru mırıldayarak yaklaşıyoruz! 🌟😻",
        "Tombul yanaklı kedişler derneği bu ilerlemeyi çok beğendi! Harika! 🐾✨",
        "Miyavv! Yağmur bugün çok fit ve enerjik görünüyor! Patiler havaya! 🎉🐾",
        "Mırr-melodi! Diyet günlüğü her geçen gün daha da güzelleşiyor! 🐾🎶"
    )

    private val _currentCatPhrase = MutableStateFlow(catPhrases.first())
    val currentCatPhrase: StateFlow<String> = _currentCatPhrase.asStateFlow()

    private val _cheatCount = MutableStateFlow(0)
    val cheatCount: StateFlow<Int> = _cheatCount.asStateFlow()

    private val _showCheatAnimation = MutableStateFlow(false)
    val showCheatAnimation: StateFlow<Boolean> = _showCheatAnimation.asStateFlow()

    init {
        _cheatCount.value = prefs.getInt("cheat_count", 0)
        val database = AppDatabase.getDatabase(application)
        repository = DiyetRepository(database)

        weightRecords = repository.weightRecords
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        bodyMeasurements = repository.bodyMeasurements
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        // Profile mapping to ensure we always have a profile (default values)
        userProfile = repository.userProfile
            .map { it ?: UserProfile(name = "Yağmur", startWeight = 65.0f, targetWeight = 55.0f, xp = 100) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserProfile(name = "Yağmur", startWeight = 65.0f, targetWeight = 55.0f, xp = 100))

        totalWeightLost = combine(userProfile, weightRecords) { profile, records ->
            val latestWeight = records.sortedBy { it.date }.lastOrNull()?.weight ?: profile.startWeight
            (profile.startWeight - latestWeight).coerceAtLeast(0.0f)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0f)

        // Auto initialize database profile if not existing
        viewModelScope.launch {
            repository.userProfile.first().let {
                if (it == null) {
                    repository.updateProfile(UserProfile(id = 1, name = "Yağmur", startWeight = 65.0f, targetWeight = 55.0f, xp = 100))
                }
            }
        }

        // Collect XP and weight loss updates to check achievements!
        viewModelScope.launch {
            combine(userProfile, totalWeightLost) { profile, totalLost ->
                Pair(profile, totalLost)
            }.collect { (profile, totalLost) ->
                checkForNewAchievements(profile.xp, totalLost)
            }
        }
    }

    fun setYearAndMonth(year: Int, month: Int) {
        _selectedYear.value = year
        _selectedMonth.value = month
    }

    fun incrementMonth() {
        if (_selectedMonth.value == 12) {
            _selectedMonth.value = 1
            _selectedYear.value += 1
        } else {
            _selectedMonth.value += 1
        }
    }

    fun decrementMonth() {
        if (_selectedMonth.value == 1) {
            _selectedMonth.value = 12
            _selectedYear.value -= 1
        } else {
            _selectedMonth.value -= 1
        }
    }

    fun addWeightRecord(date: String, weight: Float, calorieIntake: Int, calorieBurned: Int) {
        viewModelScope.launch {
            // Find if we had previous records to check weight loss
            val previousRecords = weightRecords.value.sortedBy { it.date }
            val latestWeightBefore = previousRecords.lastOrNull { it.date < date }?.weight
                ?: userProfile.value.startWeight

            val lostWeight = weight < latestWeightBefore

            // Save the record
            repository.insertWeightRecord(WeightRecord(date, weight, calorieIntake, calorieBurned))

            // Update user XP
            val profile = userProfile.value
            var xpReward = 10 // default record entry reward
            if (lostWeight) {
                xpReward += 25 // weight loss bonus!
                _showConfetti.value = true
                _currentCatPhrase.value = catPhrases.random()
            } else {
                // Regular motivation when weight is recorded
                if (Math.random() > 0.5) {
                    _currentCatPhrase.value = "Yeni veri girildi! Harika disiplin Yağmur! 🐾✨"
                }
            }

            repository.updateProfile(profile.copy(xp = profile.xp + xpReward))

            // Check for 10kg milestone celebration
            val totalLostAfter = profile.startWeight - weight
            if (totalLostAfter >= 10.0f && !prefs.getBoolean("celebrated_10kg", false)) {
                _show10KgCelebration.value = true
                prefs.edit().putBoolean("celebrated_10kg", true).apply()
                com.example.util.AmbientSynth.playFanfare()
            }
        }
    }

    fun addBodyMeasurement(date: String, waist: Float, hips: Float, chest: Float, arm: Float, leg: Float) {
        viewModelScope.launch {
            repository.insertBodyMeasurement(
                BodyMeasurement(
                    date = date,
                    waist = waist,
                    hips = hips,
                    chest = chest,
                    arm = arm,
                    leg = leg
                )
            )

            // Reward XP
            val profile = userProfile.value
            repository.updateProfile(profile.copy(xp = profile.xp + 15))
        }
    }

    fun deleteBodyMeasurement(id: Long) {
        viewModelScope.launch {
            repository.deleteBodyMeasurement(id)
        }
    }

    fun deleteWeightRecord(record: WeightRecord) {
        viewModelScope.launch {
            repository.deleteWeightRecord(record)
        }
    }

    fun updateProfileSettings(name: String, startWeight: Float, targetWeight: Float) {
        viewModelScope.launch {
            val currentProfile = userProfile.value
            repository.updateProfile(
                currentProfile.copy(
                    name = name,
                    startWeight = startWeight,
                    targetWeight = targetWeight
                )
            )
        }
    }

    fun addXp(amount: Int) {
        viewModelScope.launch {
            val currentProfile = userProfile.value
            repository.updateProfile(currentProfile.copy(xp = currentProfile.xp + amount))
        }
    }

    fun dismissConfetti() {
        _showConfetti.value = false
    }

    // --- MEAL REMINDERS SECTION ---
    data class MealReminder(
        val id: Int,
        val name: String,
        val defaultMessage: String,
        val hour: Int,
        val minute: Int,
        val isEnabled: Boolean
    )

    private val _mealReminders = MutableStateFlow<List<MealReminder>>(emptyList())
    val mealReminders: StateFlow<List<MealReminder>> = _mealReminders.asStateFlow()

    init {
        loadMealReminders()
    }

    private fun loadMealReminders() {
        val defaultReminders = listOf(
            MealReminder(1, "Kahvaltı 🍳", "Günün en tatlı öğünü! Kahvaltı saati geldi Yağmur, pati gücüyle güne başla! 🐾🍳", 8, 30, false),
            MealReminder(2, "Öğle Yemeği 🥗", "Miyav! Öğle yemeği vakti geldi. Sağlıklı seçimlerinle tabağını renklendir! 🥗😻", 13, 0, false),
            MealReminder(3, "Ara Öğün 🍎", "Ara öğün zamanı! Küçük bir meyve ya da sağlıklı bir atıştırmalık seni enerjik tutar, mırrr! 🍎🐾", 16, 30, false),
            MealReminder(4, "Akşam Yemeği 🥣", "Günü hafif kapatıyoruz! Akşam yemeği saati geldi, patilerine sağlık Yağmur! 🥣✨", 19, 30, false)
        )

        val loaded = defaultReminders.map { defaultItem ->
            val isEnabled = prefs.getBoolean("meal_enabled_${defaultItem.id}", defaultItem.isEnabled)
            val hour = prefs.getInt("meal_hour_${defaultItem.id}", defaultItem.hour)
            val minute = prefs.getInt("meal_minute_${defaultItem.id}", defaultItem.minute)
            defaultItem.copy(isEnabled = isEnabled, hour = hour, minute = minute)
        }
        _mealReminders.value = loaded
    }

    fun toggleMealReminder(reminderId: Int) {
        val updated = _mealReminders.value.map { item ->
            if (item.id == reminderId) {
                val nextState = !item.isEnabled
                prefs.edit().putBoolean("meal_enabled_${reminderId}", nextState).apply()
                
                // Reschedule or cancel
                val context = getApplication<Application>().applicationContext
                if (nextState) {
                    com.example.MealReminderScheduler.scheduleMealReminder(
                        context, item.id, item.name, item.defaultMessage, item.hour, item.minute
                    )
                } else {
                    com.example.MealReminderScheduler.cancelMealReminder(context, item.id)
                }

                item.copy(isEnabled = nextState)
            } else {
                item
            }
        }
        _mealReminders.value = updated
    }

    fun updateMealTime(reminderId: Int, hour: Int, minute: Int) {
        val updated = _mealReminders.value.map { item ->
            if (item.id == reminderId) {
                prefs.edit().putInt("meal_hour_${reminderId}", hour).apply()
                prefs.edit().putInt("meal_minute_${reminderId}", minute).apply()

                val context = getApplication<Application>().applicationContext
                // Reschedule if enabled
                if (item.isEnabled) {
                    com.example.MealReminderScheduler.scheduleMealReminder(
                        context, item.id, item.name, item.defaultMessage, hour, minute
                    )
                }

                item.copy(hour = hour, minute = minute)
            } else {
                item
            }
        }
        _mealReminders.value = updated
    }

    fun triggerTestNotification(reminderId: Int) {
        val reminder = _mealReminders.value.find { it.id == reminderId } ?: return
        val context = getApplication<Application>().applicationContext
        com.example.MealReminderScheduler.triggerInstantTestNotification(
            context, reminder.name, reminder.defaultMessage
        )
    }

    fun toggleBgMusic() {
        val nextState = !_bgMusicEnabled.value
        prefs.edit().putBoolean("bg_music_enabled", nextState).apply()
        _bgMusicEnabled.value = nextState
        com.example.util.AmbientSynth.setMusicEnabled(nextState)
    }

    fun trigger10KgCelebrationManual() {
        _show10KgCelebration.value = true
        com.example.util.AmbientSynth.playFanfare()
    }

    fun dismiss10KgCelebration() {
        _show10KgCelebration.value = false
    }

    fun incrementCheatCount() {
        viewModelScope.launch {
            val nextVal = _cheatCount.value + 1
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            prefs.edit()
                .putInt("cheat_count", nextVal)
                .putString("last_cheat_date", todayStr)
                .apply()
            _cheatCount.value = nextVal
            _showCheatAnimation.value = true
            
            _currentCatPhrase.value = listOf(
                "Aha! Yakalandın Yağmur! O balık kılçığı ne öyle? 🐟😾",
                "Kaçamak mı? Milka çok sevindi ama Pufpuf patisini masaya vuruyor! 🐾💥",
                "Miyav! Kaçamak kaydoldu. Olsun, yarın daha disiplinli oluruz! 💕🐈",
                "Dengelemek için akşam yürüyüşünü 15 dakika uzatalım mırrr! 🏃‍♀️✨"
            ).random()

            // Play a synthetic meow sound
            com.example.util.AmbientSynth.playMeowSound(getApplication<Application>().applicationContext)
        }
    }

    private fun checkForNewAchievements(xp: Int, totalLost: Float) {
        val unlockedSet = prefs.getStringSet("unlocked_badge_ids", emptySet()) ?: emptySet()
        val newlyUnlocked = badgesList.firstOrNull { badge ->
            !unlockedSet.contains(badge.id.toString()) && (
                if (badge.isXpBased) xp >= badge.threshold else totalLost >= badge.threshold
            )
        }

        if (newlyUnlocked != null) {
            val updatedSet = unlockedSet.toMutableSet().apply { add(newlyUnlocked.id.toString()) }
            prefs.edit().putStringSet("unlocked_badge_ids", updatedSet).apply()
            _newlyUnlockedBadge.value = newlyUnlocked
            
            // Trigger a push notification for this newly unlocked badge!
            triggerBadgeNotification(newlyUnlocked.name)
        }
    }

    private fun triggerBadgeNotification(badgeName: String) {
        val context = getApplication<Application>().applicationContext
        val channelId = "patili_diyet_badge_notifications"
        val notificationManager = context.getSystemService(android.content.Context.NOTIFICATION_SERVICE) as android.app.NotificationManager

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val channelName = "Patili Diyet Başarı Bildirimleri"
            val channelDescription = "Kazanılan rozet ve başarı bildirimleri"
            val importance = android.app.NotificationManager.IMPORTANCE_HIGH
            val channel = android.app.NotificationChannel(channelId, channelName, importance).apply {
                description = channelDescription
            }
            notificationManager.createNotificationChannel(channel)
        }

        val clickIntent = android.content.Intent(context, com.example.MainActivity::class.java).apply {
            flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = android.app.PendingIntent.getActivity(
            context,
            badgeName.hashCode(),
            clickIntent,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )

        val notification = androidx.core.app.NotificationCompat.Builder(context, channelId)
            .setSmallIcon(com.example.R.drawable.ic_paw_notification)
            .setContentTitle("Yeni Rozet Kazanıldı! 🏆🐾")
            .setContentText("Tebrikler Yağmur! '$badgeName' başarısını kilitledin!")
            .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setColor(0xFFFF94B9.toInt())
            .build()

        try {
            notificationManager.notify(badgeName.hashCode(), notification)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun dismissCheatAnimation() {
        _showCheatAnimation.value = false
    }
}
