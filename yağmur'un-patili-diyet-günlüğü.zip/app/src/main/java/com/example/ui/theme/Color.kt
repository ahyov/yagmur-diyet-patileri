package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cute Cat & Soft Pink Theme Palette
val CutePinkPrimary = Color(0xFFFF94B9)       // Deep cute pink for primary buttons & highlights
val CutePinkSecondary = Color(0xFFFFB5D0)     // Soft cute pink for sub-elements
val CutePinkTertiary = Color(0xFFFFD1E1)      // Lighter accent pink
val CuteCreamBackground = Color(0xFFFFFBF7)    // Warm sweet cream background
val CuteCreamSurface = Color(0xFFFFF5F2)       // Soft card surfaces

val TextDark = Color(0xFF4E3629)               // Sweet chocolate brown for high contrast text
val TextLight = Color(0xFF8D6E63)              // Lighter brown for secondary text

// Sticky Note (Post-it) Pastel Colors
val PostitYellow = Color(0xFFFEF5C2)
val PostitPink = Color(0xFFFFE3E8)
val PostitBlue = Color(0xFFD6F0FF)
val PostitGreen = Color(0xFFE2F7E6)
val PostitOrange = Color(0xFFFFEAD2)

val DarkPinkPrimary = Color(0xFFFF6F91)
val DarkPinkSecondary = Color(0xFFFF96AD)
val DarkCreamBackground = Color(0xFF2D2522)
val DarkCreamSurface = Color(0xFF3D322E)
val DarkTextDark = Color(0xFFFFF0EC)
val DarkTextLight = Color(0xFFD7CCC8)
