package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import kotlin.random.Random

@Composable
fun CuteCatFace(
    modifier: Modifier = Modifier,
    primaryColor: Color = Color(0xFFFFB5D0),
    detailColor: Color = Color(0xFF4E3629)
) {
    Canvas(modifier = modifier.aspectRatio(1f)) {
        val w = size.width
        val h = size.height
        val cols = 16
        val rows = 16
        val px = w / cols
        val py = h / rows

        // High quality pixel art palette for the iconic cat face
        val grey = Color(0xFFB0BEC5)
        val darkGrey = Color(0xFF546E7A)
        val pink = Color(0xFFFF8A80)
        val black = Color(0xFF263238)
        val white = Color(0xFFFFFFFF)

        val grid = arrayOf(
            "................",
            "................",
            "..X..........X..",
            "..XX........XX..",
            "..XpX......XpX..",
            "..XpX......XpX..",
            ".XXXXXXXXXXXXXX.",
            ".XGGGGGGGGGGGGX.",
            "XGGSDGGGGGGDSGGX",
            "XGGSDGGGGGGDSGGX",
            "XGGGGGGGGGGGGGGX",
            "XGGGPBGGGGGBPBBX",
            "XGGGGGGWWGGGGGGX",
            "XGGGGGWWWWGGGGGX",
            ".XXXXXXXXXXXXXX.",
            "................"
        )

        for (r in 0 until rows) {
            val line = grid[r]
            for (c in 0 until cols) {
                if (c < line.length) {
                    val ch = line[c]
                    val color = when (ch) {
                        'X' -> black
                        'G' -> grey
                        'S' -> darkGrey
                        'p' -> pink
                        'P' -> pink
                        'B' -> black
                        'W' -> white
                        'D' -> white
                        else -> null
                    }
                    if (color != null) {
                        drawRect(
                            color = color,
                            topLeft = Offset(c * px, r * py),
                            size = Size(px + 0.5f, py + 0.5f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CuteCatPaw(
    modifier: Modifier = Modifier,
    color: Color = Color(0xFFFFB5D0),
    padColor: Color = Color(0xFFFF7A9F)
) {
    Canvas(modifier = modifier.aspectRatio(1f)) {
        val w = size.width
        val h = size.height

        // Main paw container
        drawCircle(
            color = color,
            radius = w * 0.32f,
            center = Offset(w * 0.5f, h * 0.55f)
        )

        // Three toes
        drawCircle(color = color, radius = w * 0.12f, center = Offset(w * 0.25f, h * 0.30f))
        drawCircle(color = color, radius = w * 0.14f, center = Offset(w * 0.50f, h * 0.22f))
        drawCircle(color = color, radius = w * 0.12f, center = Offset(w * 0.75f, h * 0.30f))

        // Large pad inside paw (kidney bean shape or large rounded tri)
        drawCircle(
            color = padColor,
            radius = w * 0.18f,
            center = Offset(w * 0.5f, h * 0.58f)
        )
        drawCircle(
            color = padColor,
            radius = w * 0.09f,
            center = Offset(w * 0.38f, h * 0.53f)
        )
        drawCircle(
            color = padColor,
            radius = w * 0.09f,
            center = Offset(w * 0.62f, h * 0.53f)
        )

        // Small toe pads
        drawCircle(color = padColor, radius = w * 0.06f, center = Offset(w * 0.25f, h * 0.30f))
        drawCircle(color = padColor, radius = w * 0.07f, center = Offset(w * 0.50f, h * 0.22f))
        drawCircle(color = padColor, radius = w * 0.06f, center = Offset(w * 0.75f, h * 0.30f))
    }
}

@Composable
fun CuteConfetti(
    modifier: Modifier = Modifier,
    colorList: List<Color> = listOf(
        Color(0xFFFFB7B2), Color(0xFFFFDAC1), Color(0xFFE2F0CB),
        Color(0xFFB5EAD7), Color(0xFFC7CEEA), Color(0xFFFFC6FF),
        Color(0xFFFFADAD), Color(0xFF9BF6FF), Color(0xFFFFD6A5)
    )
) {
    val numParticles = 45
    val infiniteTransition = rememberInfiniteTransition(label = "ConfettiTransition")

    val particles = remember {
        List(numParticles) {
            ConfettiParticle(
                x = Random.nextFloat(),
                yStart = -Random.nextFloat() * 200f,
                speed = 100f + Random.nextFloat() * 200f,
                size = 10f + Random.nextFloat() * 25f,
                color = colorList.random(),
                angleSpeed = 30f + Random.nextFloat() * 120f,
                swayAmplitude = 10f + Random.nextFloat() * 40f,
                shape = if (Random.nextBoolean()) ParticleShape.Circle else ParticleShape.Rect
            )
        }
    }

    val progress = infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 5000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Progress"
    )

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        particles.forEach { p ->
            val elapsedSecs = progress.value * 5f
            val currentY = (p.yStart + p.speed * elapsedSecs) % (h + 50f)
            val sway = kotlin.math.sin(elapsedSecs * 3.14f + p.x * 10f) * p.swayAmplitude
            val currentX = (p.x * w + sway) % w

            val angle = p.angleSpeed * elapsedSecs

            // Render shape
            if (p.shape == ParticleShape.Circle) {
                drawCircle(
                    color = p.color,
                    radius = p.size / 2f,
                    center = Offset(currentX, currentY)
                )
            } else {
                val sizePx = p.size
                rotate(angle, pivot = Offset(currentX, currentY)) {
                    drawRect(
                        color = p.color,
                        topLeft = Offset(currentX - sizePx / 2f, currentY - sizePx / 2f),
                        size = Size(sizePx, sizePx)
                    )
                }
            }
        }
    }
}

enum class ParticleShape { Circle, Rect }

data class ConfettiParticle(
    val x: Float,
    val yStart: Float,
    val speed: Float,
    val size: Float,
    val color: Color,
    val angleSpeed: Float,
    val swayAmplitude: Float,
    val shape: ParticleShape
)

// --- PIXEL ART CAT COMPONENT SUITE ---

@Composable
fun PixelArtCat(
    grid: Array<String>,
    colorMap: Map<Char, Color>,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.aspectRatio(1f)) {
        val numRows = grid.size
        val numCols = grid[0].length
        val pixelWidth = size.width / numCols
        val pixelHeight = size.height / numRows

        for (r in 0 until numRows) {
            val rowStr = grid[r]
            for (c in 0 until numCols) {
                val char = rowStr[c]
                val color = colorMap[char]
                if (color != null && color != Color.Transparent) {
                    drawRect(
                        color = color,
                        topLeft = Offset(c * pixelWidth, r * pixelHeight),
                        size = Size(pixelWidth + 0.5f, pixelHeight + 0.5f) // avoid thin lines with subpixel rendering
                    )
                }
            }
        }
    }
}

@Composable
fun PixelArtPufpuf(modifier: Modifier = Modifier) {
    val pufpufGrid = remember {
        arrayOf(
            "................",
            "XX..........XX..",
            "XPPX......XPPX..",
            "XGGGX....XGGGX..",
            "XGDDGXXXXGDDGX..",
            "XGGGGGGGGGGGGX..",
            "XGDDGDDGDDGGGX..",
            "XGGGGGGGGGGGGX..",
            "XGYXGGGGGGXYGX..",
            "XGXXGGPXGGXXGX..",
            "XGGGXXXXXXGGGX..",
            "XGGXWWXXWWXGGX..",
            "XGGGXXXXXXGGGX..",
            ".XGGGGGGGGGGX...",
            "..XXXXXXXXXX....",
            "................"
        )
    }

    val colorMap = remember {
        mapOf(
            '.' to Color.Transparent,
            'X' to Color(0xFF252525), // Strong outline
            'G' to Color(0xFF9E9E9E), // Classic grey tabby base
            'D' to Color(0xFF515151), // Dark stripes
            'P' to Color(0xFFFFB2C9), // Cute pink ears/nose
            'Y' to Color(0xFFFFD54F), // Serious yellow eyes
            'W' to Color(0xFFF5F5F5)  // Light muzzle details
        )
    }

    PixelArtCat(grid = pufpufGrid, colorMap = colorMap, modifier = modifier)
}

@Composable
fun PixelArtMilka(modifier: Modifier = Modifier) {
    val milkaGrid = remember {
        arrayOf(
            "................",
            ".XX........XX...",
            "XPPX......XPPX..",
            "XWWSXXXXXXSWWX..",
            "XWWWWWWWWWWWWX..",
            "XWWSWWSWWSWWWX..",
            "XWWWWWWWWWWWWX..",
            "XWXBXWWWWXAXWX..",
            "XWXXWWNWWXXWWX..",
            "XWWWWXXXXWWWWX..",
            "XWWXWWSWWWXWWX..",
            "XWWWWWWWWWWWWX..",
            ".XWWWWWWWWWWX...",
            "..XWWWWWWWWX....",
            "...XXXXXXXX.....",
            "................"
        )
    }

    val colorMap = remember {
        mapOf(
            '.' to Color.Transparent,
            'X' to Color(0xFF333333), // Sharp outline
            'W' to Color(0xFFFFFFFF), // Fluffy white Ankara kedi
            'S' to Color(0xFFE5E5E5), // Soft grey shadows/fluff depth
            'P' to Color(0xFFFFB2C9), // Soft pink inner ear
            'N' to Color(0xFFFFA2B2), // Silly pink nose
            'B' to Color(0xFF29B6F6), // Wide blue heterochromia eye
            'A' to Color(0xFF81C784)  // Silly green heterochromia eye
        )
    }

    PixelArtCat(grid = milkaGrid, colorMap = colorMap, modifier = modifier)
}
