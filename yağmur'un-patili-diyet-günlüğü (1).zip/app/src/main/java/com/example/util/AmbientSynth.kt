package com.example.util

import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.sin

object AmbientSynth {
    private const val SAMPLE_RATE = 22050
    private var audioTrack: AudioTrack? = null
    private var musicJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    @Volatile
    private var isPlaying = false

    @Volatile
    private var isMusicEnabled = false

    // Frequencies for a beautiful, peaceful pentatonic progression (C major / A minor pentatonic)
    private val pianoNotes = doubleArrayOf(261.63, 293.66, 329.63, 392.00, 440.00, 523.25, 659.25, 783.99)
    
    // Slow chord roots for background "violin" pad (warm sine/triangle wave chords)
    private val violinChords = arrayOf(
        doubleArrayOf(130.81, 164.81, 196.00), // C3, E3, G3
        doubleArrayOf(174.61, 220.00, 261.63), // F3, A3, C4
        doubleArrayOf(110.00, 130.81, 164.81), // A2, C3, E3
        doubleArrayOf(98.00, 123.47, 146.83)   // G2, B2, D3
    )

    fun initSynth(enabled: Boolean) {
        try {
            isMusicEnabled = enabled
            if (isMusicEnabled) {
                start()
            }
        } catch (t: Throwable) {
            t.printStackTrace()
        }
    }

    @Synchronized
    fun setMusicEnabled(enabled: Boolean) {
        try {
            isMusicEnabled = enabled
            if (enabled) {
                start()
            } else {
                stop()
            }
        } catch (t: Throwable) {
            t.printStackTrace()
        }
    }

    fun isEnabled(): Boolean = isMusicEnabled

    @Synchronized
    fun start() {
        try {
            if (isPlaying) return
            isPlaying = true

            val minBufferSize = try {
                AudioTrack.getMinBufferSize(
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
            } catch (t: Throwable) {
                t.printStackTrace()
                5000
            }

            audioTrack = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                AudioTrack.Builder()
                    .setAudioAttributes(
                        android.media.AudioAttributes.Builder()
                            .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(SAMPLE_RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(minBufferSize * 2)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
            } else {
                @Suppress("DEPRECATION")
                AudioTrack(
                    AudioManager.STREAM_MUSIC,
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    minBufferSize * 2,
                    AudioTrack.MODE_STREAM
                )
            }

            audioTrack?.play()
        } catch (t: Throwable) {
            t.printStackTrace()
            isPlaying = false
            return
        }

        try {
            musicJob = scope.launch {
                var chordIndex = 0
                var tick = 0
                
                // Soothing audio loop
                while (isPlaying) {
                    try {
                        // Periodically shift the background violin chord every ~4 seconds
                        if (tick % 40 == 0) {
                            chordIndex = (chordIndex + 1) % violinChords.size
                        }

                        // Randomly trigger a piano note every 1-2 seconds
                        val playPiano = tick % 15 == 0 || (tick % 15 != 0 && Math.random() < 0.15)
                        val pianoFreq = if (playPiano) pianoNotes.random() else 0.0

                        // Generate a 100ms chunk of audio
                        val chunkDurationMs = 100
                        val numSamples = (SAMPLE_RATE * chunkDurationMs) / 1000
                        val buffer = ShortArray(numSamples)

                        val activeChords = violinChords[chordIndex]

                        for (i in 0 until numSamples) {
                            val t = (tick * numSamples + i).toDouble() / SAMPLE_RATE

                            // 1. Synthesize background violin (3 oscillators with sweet vibrato & tremolo)
                            var violinSum = 0.0
                            val vibrato = 1.0 + 0.015 * sin(2.0 * Math.PI * 5.5 * t) // 5.5 Hz vibrato
                            for (f in activeChords) {
                                violinSum += sin(2.0 * Math.PI * (f * vibrato) * t)
                            }
                            violinSum /= activeChords.size
                            val tremolo = 0.55 + 0.45 * sin(2.0 * Math.PI * 0.18 * t)
                            val violinSample = violinSum * tremolo * 0.12 // Keep background soft

                            // 2. Synthesize gentle piano/bell drop
                            var pianoSample = 0.0
                            if (pianoFreq > 0) {
                                val noteAge = (i.toDouble() / SAMPLE_RATE)
                                val decay = Math.exp(-3.5 * noteAge)
                                val sineTone = sin(2.0 * Math.PI * pianoFreq * t)
                                val harmonicTone = sin(2.0 * Math.PI * (pianoFreq * 2.0) * t) * 0.3
                                pianoSample = (sineTone + harmonicTone) * decay * 0.35
                            }

                            val finalSample = (violinSample + pianoSample).coerceIn(-1.0, 1.0)
                            buffer[i] = (finalSample * Short.MAX_VALUE).toInt().toShort()
                        }

                        audioTrack?.write(buffer, 0, buffer.size)
                    } catch (t: Throwable) {
                        t.printStackTrace()
                        break
                    }

                    tick++
                    delay(100)
                }
            }
        } catch (t: Throwable) {
            t.printStackTrace()
        }
    }

    @Synchronized
    fun stop() {
        try {
            isPlaying = false
            musicJob?.cancel()
            musicJob = null
            try {
                audioTrack?.stop()
                audioTrack?.release()
            } catch (t: Throwable) {
                t.printStackTrace()
            }
            audioTrack = null
        } catch (t: Throwable) {
            t.printStackTrace()
        }
    }

    // Play a magical 10kg achievement celebration fanfare in a non-blocking thread!
    fun playFanfare() {
        scope.launch {
            var fanfareTrack: AudioTrack? = null
            try {
                val minBufferSize = try {
                    AudioTrack.getMinBufferSize(
                        SAMPLE_RATE,
                        AudioFormat.CHANNEL_OUT_MONO,
                        AudioFormat.ENCODING_PCM_16BIT
                    )
                } catch (t: Throwable) {
                    t.printStackTrace()
                    5000
                }
                
                fanfareTrack = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    AudioTrack.Builder()
                        .setAudioAttributes(
                            android.media.AudioAttributes.Builder()
                                .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                                .build()
                        )
                        .setAudioFormat(
                            AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(SAMPLE_RATE)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                .build()
                        )
                        .setBufferSizeInBytes(minBufferSize * 2)
                        .setTransferMode(AudioTrack.MODE_STREAM)
                        .build()
                } else {
                    @Suppress("DEPRECATION")
                    AudioTrack(
                        AudioManager.STREAM_MUSIC,
                        SAMPLE_RATE,
                        AudioFormat.CHANNEL_OUT_MONO,
                        AudioFormat.ENCODING_PCM_16BIT,
                        minBufferSize * 2,
                        AudioTrack.MODE_STREAM
                    )
                }

                fanfareTrack?.play()

                // Melody of the fanfare: E5, G5, C6, E6
                val notes = doubleArrayOf(659.25, 783.99, 1046.50, 1318.51)
                val durationMs = 350
                val samplesPerNote = (SAMPLE_RATE * durationMs) / 1000

                for (noteFreq in notes) {
                    val buffer = ShortArray(samplesPerNote)
                    for (i in 0 until samplesPerNote) {
                        val t = i.toDouble() / SAMPLE_RATE
                        val decay = Math.exp(-2.0 * t)
                        val sample = sin(2.0 * Math.PI * noteFreq * t) * decay * 0.4
                        buffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
                    }
                    fanfareTrack?.write(buffer, 0, buffer.size)
                }

                // Final sustained chord (C6 + E6 + G6)
                val finalDurationMs = 1200
                val finalSamples = (SAMPLE_RATE * finalDurationMs) / 1000
                val finalBuffer = ShortArray(finalSamples)
                val finalChord = doubleArrayOf(1046.50, 1318.51, 1567.98)

                for (i in 0 until finalSamples) {
                    val t = i.toDouble() / SAMPLE_RATE
                    val decay = Math.exp(-1.5 * t)
                    var sampleSum = 0.0
                    for (f in finalChord) {
                        sampleSum += sin(2.0 * Math.PI * f * t)
                    }
                    val sample = (sampleSum / finalChord.size) * decay * 0.5
                    finalBuffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
                }
                fanfareTrack?.write(finalBuffer, 0, finalBuffer.size)

                delay(2500)
                fanfareTrack?.stop()
                fanfareTrack?.release()
            } catch (t: Throwable) {
                t.printStackTrace()
                try {
                    fanfareTrack?.release()
                } catch (ex: Exception) {}
            }
        }
    }

    // Safely plays a meow sound using MediaPlayer with synthetic fallback
    fun playMeowSound(context: android.content.Context? = null) {
        scope.launch {
            try {
                if (context != null) {
                    val resourceId = context.resources.getIdentifier("meow", "raw", context.packageName)
                    if (resourceId != 0) {
                        val mediaPlayer = android.media.MediaPlayer.create(context, resourceId)
                        mediaPlayer?.setOnCompletionListener {
                            it.release()
                        }
                        mediaPlayer?.start()
                        return@launch
                    }
                }
            } catch (t: Throwable) {
                t.printStackTrace()
            }
            // fallback if no file or exception occurred
            playSyntheticMeow()
        }
    }

    // Cute retro synth meow! Sweeps from 500Hz up to 800Hz, then slides down to 400Hz
    fun playSyntheticMeow() {
        scope.launch {
            var track: AudioTrack? = null
            try {
                val minBufferSize = try {
                    AudioTrack.getMinBufferSize(
                        SAMPLE_RATE,
                        AudioFormat.CHANNEL_OUT_MONO,
                        AudioFormat.ENCODING_PCM_16BIT
                    )
                } catch (t: Throwable) {
                    t.printStackTrace()
                    5000
                }
                
                track = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    AudioTrack.Builder()
                        .setAudioAttributes(
                            android.media.AudioAttributes.Builder()
                                .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                                .build()
                        )
                        .setAudioFormat(
                            AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(SAMPLE_RATE)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                .build()
                        )
                        .setBufferSizeInBytes(minBufferSize * 2)
                        .setTransferMode(AudioTrack.MODE_STREAM)
                        .build()
                } else {
                    @Suppress("DEPRECATION")
                    AudioTrack(
                        AudioManager.STREAM_MUSIC,
                        SAMPLE_RATE,
                        AudioFormat.CHANNEL_OUT_MONO,
                        AudioFormat.ENCODING_PCM_16BIT,
                        minBufferSize * 2,
                        AudioTrack.MODE_STREAM
                    )
                }

                track?.play()

                val durationMs = 450
                val totalSamples = (SAMPLE_RATE * durationMs) / 1000
                val buffer = ShortArray(totalSamples)

                for (i in 0 until totalSamples) {
                    val t = i.toDouble() / SAMPLE_RATE
                    val progress = t / (durationMs.toDouble() / 1000.0)
                    
                    val freq = if (progress < 0.25) {
                        500.0 + (300.0 * (progress / 0.25)) // 500 -> 800
                    } else {
                        800.0 - (400.0 * ((progress - 0.25) / 0.75)) // 800 -> 400
                    }

                    val envelope = if (progress < 0.1) {
                        progress / 0.1 // Attack
                    } else if (progress < 0.8) {
                        1.0 - 0.3 * ((progress - 0.1) / 0.7) // Sustain
                    } else {
                        0.7 * (1.0 - (progress - 0.8) / 0.2) // Release
                    }

                    val tone = sin(2.0 * Math.PI * freq * t) + 0.3 * sin(2.0 * Math.PI * (freq * 1.5) * t)
                    val sample = (tone / 1.3) * envelope * 0.25
                    buffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
                }

                track?.write(buffer, 0, buffer.size)
                delay(600)
                track?.stop()
                track?.release()
            } catch (t: Throwable) {
                t.printStackTrace()
                try {
                    track?.release()
                } catch (ex: Exception) {}
            }
        }
    }

    fun playMeow(context: android.content.Context? = null) {
        playMeowSound(context)
    }

    fun playPurr(context: android.content.Context? = null) {
        scope.launch {
            try {
                if (context != null) {
                    val resourceId = context.resources.getIdentifier("purr", "raw", context.packageName)
                    if (resourceId != 0) {
                        val mediaPlayer = android.media.MediaPlayer.create(context, resourceId)
                        mediaPlayer?.setOnCompletionListener {
                            it.release()
                        }
                        mediaPlayer?.start()
                        return@launch
                    }
                }
            } catch (t: Throwable) {
                t.printStackTrace()
            }
            playSyntheticPurr()
        }
    }

    fun playSyntheticPurr() {
        scope.launch {
            var track: AudioTrack? = null
            try {
                val minBufferSize = try {
                    AudioTrack.getMinBufferSize(
                        SAMPLE_RATE,
                        AudioFormat.CHANNEL_OUT_MONO,
                        AudioFormat.ENCODING_PCM_16BIT
                    )
                } catch (t: Throwable) {
                    t.printStackTrace()
                    5000
                }
                
                track = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    AudioTrack.Builder()
                        .setAudioAttributes(
                            android.media.AudioAttributes.Builder()
                                .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                                .build()
                        )
                        .setAudioFormat(
                            AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(SAMPLE_RATE)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                .build()
                        )
                        .setBufferSizeInBytes(minBufferSize * 2)
                        .setTransferMode(AudioTrack.MODE_STREAM)
                        .build()
                } else {
                    @Suppress("DEPRECATION")
                    AudioTrack(
                        AudioManager.STREAM_MUSIC,
                        SAMPLE_RATE,
                        AudioFormat.CHANNEL_OUT_MONO,
                        AudioFormat.ENCODING_PCM_16BIT,
                        minBufferSize * 2,
                        AudioTrack.MODE_STREAM
                    )
                }

                track?.play()

                val durationMs = 800
                val totalSamples = (SAMPLE_RATE * durationMs) / 1000
                val buffer = ShortArray(totalSamples)

                for (i in 0 until totalSamples) {
                    val t = i.toDouble() / SAMPLE_RATE
                    val rumble = sin(2.0 * Math.PI * 65.0 * t) + 0.3 * sin(2.0 * Math.PI * 130.0 * t)
                    val modulation = 0.5 + 0.5 * sin(2.0 * Math.PI * 22.0 * t)
                    val progress = t / (durationMs.toDouble() / 1000.0)
                    val envelope = sin(Math.PI * progress)

                    val value = rumble * modulation * envelope * 0.45
                    buffer[i] = (value.coerceIn(-1.0, 1.0) * Short.MAX_VALUE).toInt().toShort()
                }

                track?.write(buffer, 0, buffer.size)
                delay(900)
                track?.stop()
                track?.release()
            } catch (t: Throwable) {
                t.printStackTrace()
                try {
                    track?.release()
                } catch (ex: Exception) {}
            }
        }
    }
}
