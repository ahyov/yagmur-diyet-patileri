package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class DiyetViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: DiyetRepository
    private val prefs = application.getSharedPreferences("patili_diyet_prefs", android.content.Context.MODE_PRIVATE)

    private val _bgMusicEnabled = MutableStateFlow(prefs.getBoolean("bg_music_enabled", true))
    val bgMusicEnabled: StateFlow<Boolean> = _bgMusicEnabled.asStateFlow()

    // Database Flows
    val weightRecords: StateFlow<List<WeightRecord>>
    val bodyMeasurements: StateFlow<List<BodyMeasurement>>
    val userProfile: StateFlow<UserProfile>
    val totalWeightLost: StateFlow<Float>

    // Post-it Wall Calendar Selection State
    private val _selectedYear = MutableStateFlow(Calendar.getInstance().get(Calendar.YEAR))
    val selectedYear: StateFlow<Int> = _selectedYear.asStateFlow()

    private val _selectedMonth = MutableStateFlow(Calendar.getInstance().get(Calendar.MONTH) + 1) // 1-12
    val selectedMonth: StateFlow<Int> = _selectedMonth.asStateFlow()

    // Animation & Celebration State
    private val _showConfetti = MutableStateFlow(false)
    val showConfetti: StateFlow<Boolean> = _showConfetti.asStateFlow()

    private val _show10KgCelebration = MutableStateFlow(false)
    val show10KgCelebration: StateFlow<Boolean> = _show10KgCelebration.asStateFlow()

    private val catPhrases = listOf(
        "Miyav! Harika gidiyorsun Yağmur, patilerim seni alkışlıyor! 😻",
        "Pati dostun seninle gurur duyuyor! Kilo vermen tam bir mucize, miyav! 🐾💖",
        "Mırrr... Kendini çok hafiflemiş hissediyorsun değil mi? Devam et tatlışım! 🐈",
        "Süperstar Yağmur! Hedefe doğru mırıldayarak yaklaşıyoruz! 🌟😻",
        "Tombul yanaklı kedişler derneği bu ilerlemeyi çok beğendi! Harika! 🐾✨",
        "Miyavv! Yağmur bugün çok fit ve enerjik görünüyor! Patiler havaya! 🎉🐾",
        "Mırr-melodi! Diyet günlüğü her geçen gün daha da güzelleşiyor! 🐾🎶"
    )

    private val _currentCatPhrase = MutableStateFlow(catPhrases.first())
    val currentCatPhrase: StateFlow<String> = _currentCatPhrase.asStateFlow()

    private val _cheatCount = MutableStateFlow(0)
    val cheatCount: StateFlow<Int> = _cheatCount.asStateFlow()

    private val _showCheatAnimation = MutableStateFlow(false)
    val showCheatAnimation: StateFlow<Boolean> = _showCheatAnimation.asStateFlow()

    init {
        _cheatCount.value = prefs.getInt("cheat_count", 0)
        val database = AppDatabase.getDatabase(application)
        repository = DiyetRepository(database)

        weightRecords = repository.weightRecords
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        bodyMeasurements = repository.bodyMeasurements
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        // Profile mapping to ensure we always have a profile (default values)
        userProfile = repository.userProfile
            .map { it ?: UserProfile(name = "Yağmur", startWeight = 65.0f, targetWeight = 55.0f, xp = 100) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserProfile(name = "Yağmur", startWeight = 65.0f, targetWeight = 55.0f, xp = 100))

        totalWeightLost = combine(userProfile, weightRecords) { profile, records ->
            val latestWeight = records.sortedBy { it.date }.lastOrNull()?.weight ?: profile.startWeight
            (profile.startWeight - latestWeight).coerceAtLeast(0.0f)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0f)

        // Auto initialize database profile if not existing
        viewModelScope.launch {
            repository.userProfile.first().let {
                if (it == null) {
                    repository.updateProfile(UserProfile(id = 1, name = "Yağmur", startWeight = 65.0f, targetWeight = 55.0f, xp = 100))
                }
            }
        }
    }

    fun setYearAndMonth(year: Int, month: Int) {
        _selectedYear.value = year
        _selectedMonth.value = month
    }

    fun incrementMonth() {
        if (_selectedMonth.value == 12) {
            _selectedMonth.value = 1
            _selectedYear.value += 1
        } else {
            _selectedMonth.value += 1
        }
    }

    fun decrementMonth() {
        if (_selectedMonth.value == 1) {
            _selectedMonth.value = 12
            _selectedYear.value -= 1
        } else {
            _selectedMonth.value -= 1
        }
    }

    fun addWeightRecord(date: String, weight: Float, calorieIntake: Int, calorieBurned: Int) {
        viewModelScope.launch {
            // Find if we had previous records to check weight loss
            val previousRecords = weightRecords.value.sortedBy { it.date }
            val latestWeightBefore = previousRecords.lastOrNull { it.date < date }?.weight
                ?: userProfile.value.startWeight

            val lostWeight = weight < latestWeightBefore

            // Save the record
            repository.insertWeightRecord(WeightRecord(date, weight, calorieIntake, calorieBurned))

            // Update user XP
            val profile = userProfile.value
            var xpReward = 10 // default record entry reward
            if (lostWeight) {
                xpReward += 25 // weight loss bonus!
                _showConfetti.value = true
                _currentCatPhrase.value = catPhrases.random()
            } else {
                // Regular motivation when weight is recorded
                if (Math.random() > 0.5) {
                    _currentCatPhrase.value = "Yeni veri girildi! Harika disiplin Yağmur! 🐾✨"
                }
            }

            repository.updateProfile(profile.copy(xp = profile.xp + xpReward))

            // Check for 10kg milestone celebration
            val totalLostAfter = profile.startWeight - weight
            if (totalLostAfter >= 10.0f && !prefs.getBoolean("celebrated_10kg", false)) {
                _show10KgCelebration.value = true
                prefs.edit().putBoolean("celebrated_10kg", true).apply()
                com.example.util.AmbientSynth.playFanfare()
            }
        }
    }

    fun addBodyMeasurement(date: String, waist: Float, hips: Float, chest: Float, arm: Float, leg: Float) {
        viewModelScope.launch {
            repository.insertBodyMeasurement(
                BodyMeasurement(
                    date = date,
                    waist = waist,
                    hips = hips,
                    chest = chest,
                    arm = arm,
                    leg = leg
                )
            )

            // Reward XP
            val profile = userProfile.value
            repository.updateProfile(profile.copy(xp = profile.xp + 15))
        }
    }

    fun deleteBodyMeasurement(id: Long) {
        viewModelScope.launch {
            repository.deleteBodyMeasurement(id)
        }
    }

    fun deleteWeightRecord(record: WeightRecord) {
        viewModelScope.launch {
            repository.deleteWeightRecord(record)
        }
    }

    fun updateProfileSettings(name: String, startWeight: Float, targetWeight: Float) {
        viewModelScope.launch {
            val currentProfile = userProfile.value
            repository.updateProfile(
                currentProfile.copy(
                    name = name,
                    startWeight = startWeight,
                    targetWeight = targetWeight
                )
            )
        }
    }

    fun addXp(amount: Int) {
        viewModelScope.launch {
            val currentProfile = userProfile.value
            repository.updateProfile(currentProfile.copy(xp = currentProfile.xp + amount))
        }
    }

    fun dismissConfetti() {
        _showConfetti.value = false
    }

    // --- MEAL REMINDERS SECTION ---
    data class MealReminder(
        val id: Int,
        val name: String,
        val defaultMessage: String,
        val hour: Int,
        val minute: Int,
        val isEnabled: Boolean
    )

    private val _mealReminders = MutableStateFlow<List<MealReminder>>(emptyList())
    val mealReminders: StateFlow<List<MealReminder>> = _mealReminders.asStateFlow()

    init {
        loadMealReminders()
    }

    private fun loadMealReminders() {
        val defaultReminders = listOf(
            MealReminder(1, "Kahvaltı 🍳", "Günün en tatlı öğünü! Kahvaltı saati geldi Yağmur, pati gücüyle güne başla! 🐾🍳", 8, 30, false),
            MealReminder(2, "Öğle Yemeği 🥗", "Miyav! Öğle yemeği vakti geldi. Sağlıklı seçimlerinle tabağını renklendir! 🥗😻", 13, 0, false),
            MealReminder(3, "Ara Öğün 🍎", "Ara öğün zamanı! Küçük bir meyve ya da sağlıklı bir atıştırmalık seni enerjik tutar, mırrr! 🍎🐾", 16, 30, false),
            MealReminder(4, "Akşam Yemeği 🥣", "Günü hafif kapatıyoruz! Akşam yemeği saati geldi, patilerine sağlık Yağmur! 🥣✨", 19, 30, false)
        )

        val loaded = defaultReminders.map { defaultItem ->
            val isEnabled = prefs.getBoolean("meal_enabled_${defaultItem.id}", defaultItem.isEnabled)
            val hour = prefs.getInt("meal_hour_${defaultItem.id}", defaultItem.hour)
            val minute = prefs.getInt("meal_minute_${defaultItem.id}", defaultItem.minute)
            defaultItem.copy(isEnabled = isEnabled, hour = hour, minute = minute)
        }
        _mealReminders.value = loaded
    }

    fun toggleMealReminder(reminderId: Int) {
        val updated = _mealReminders.value.map { item ->
            if (item.id == reminderId) {
                val nextState = !item.isEnabled
                prefs.edit().putBoolean("meal_enabled_${reminderId}", nextState).apply()
                
                // Reschedule or cancel
                val context = getApplication<Application>().applicationContext
                if (nextState) {
                    com.example.MealReminderScheduler.scheduleMealReminder(
                        context, item.id, item.name, item.defaultMessage, item.hour, item.minute
                    )
                } else {
                    com.example.MealReminderScheduler.cancelMealReminder(context, item.id)
                }

                item.copy(isEnabled = nextState)
            } else {
                item
            }
        }
        _mealReminders.value = updated
    }

    fun updateMealTime(reminderId: Int, hour: Int, minute: Int) {
        val updated = _mealReminders.value.map { item ->
            if (item.id == reminderId) {
                prefs.edit().putInt("meal_hour_${reminderId}", hour).apply()
                prefs.edit().putInt("meal_minute_${reminderId}", minute).apply()

                val context = getApplication<Application>().applicationContext
                // Reschedule if enabled
                if (item.isEnabled) {
                    com.example.MealReminderScheduler.scheduleMealReminder(
                        context, item.id, item.name, item.defaultMessage, hour, minute
                    )
                }

                item.copy(hour = hour, minute = minute)
            } else {
                item
            }
        }
        _mealReminders.value = updated
    }

    fun triggerTestNotification(reminderId: Int) {
        val reminder = _mealReminders.value.find { it.id == reminderId } ?: return
        val context = getApplication<Application>().applicationContext
        com.example.MealReminderScheduler.triggerInstantTestNotification(
            context, reminder.name, reminder.defaultMessage
        )
    }

    fun toggleBgMusic() {
        val nextState = !_bgMusicEnabled.value
        prefs.edit().putBoolean("bg_music_enabled", nextState).apply()
        _bgMusicEnabled.value = nextState
        com.example.util.AmbientSynth.setMusicEnabled(nextState)
    }

    fun trigger10KgCelebrationManual() {
        _show10KgCelebration.value = true
        com.example.util.AmbientSynth.playFanfare()
    }

    fun dismiss10KgCelebration() {
        _show10KgCelebration.value = false
    }

    fun incrementCheatCount() {
        viewModelScope.launch {
            val nextVal = _cheatCount.value + 1
            prefs.edit().putInt("cheat_count", nextVal).apply()
            _cheatCount.value = nextVal
            _showCheatAnimation.value = true
            
            _currentCatPhrase.value = listOf(
                "Aha! Yakalandın Yağmur! O balık kılçığı ne öyle? 🐟😾",
                "Kaçamak mı? Milka çok sevindi ama Pufpuf patisini masaya vuruyor! 🐾💥",
                "Miyav! Kaçamak kaydoldu. Olsun, yarın daha disiplinli oluruz! 💕🐈",
                "Dengelemek için akşam yürüyüşünü 15 dakika uzatalım mırrr! 🏃‍♀️✨"
            ).random()

            // Play a synthetic meow sound
            com.example.util.AmbientSynth.playMeowSound(getApplication<Application>().applicationContext)
        }
    }

    fun dismissCheatAnimation() {
        _showCheatAnimation.value = false
    }
}
