package com.example

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R

class MealReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val mealName = intent.getStringExtra("meal_name") ?: "Öğün"
        val message = intent.getStringExtra("meal_message") ?: "Beslenme saatimiz geldi, hadi tabağımızı patileyelim! 🐾"
        
        showNotification(context, mealName, message)
    }

    private fun showNotification(context: Context, title: String, text: String) {
        val channelId = "patili_diyet_notifications"
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelName = "Patili Diyet Hatırlatıcıları"
            val channelDescription = "Günlük beslenme ve öğün hatırlatıcı bildirimleri"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(channelId, channelName, importance).apply {
                description = channelDescription
            }
            notificationManager.createNotificationChannel(channel)
        }

        // Click action to open MainActivity
        val clickIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            clickIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Built-in cute message notification decoration
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_paw_notification)
            .setContentTitle("Miyav! $title Zamanı! 🐾")
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setColor(0xFFFF94B9.toInt()) // CutePinkPrimary
            .build()

        notificationManager.notify(title.hashCode(), notification)
    }
}
